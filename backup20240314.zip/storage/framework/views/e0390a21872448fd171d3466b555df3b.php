<div>
    <!--[if BLOCK]><![endif]--><?php if(
        $credit_line_id!='' &&
        $guarantee_id!='' &&
        $tecnology_id!='' &&
        $policy_id!='' &&
        $time_limit_id!='' &&
        $interest_id!='' &&
        $initial_capital!=''
    ): ?>
        <a onclick="printDiv('tabla')" class="cursor-pointer inline-flex items-center justify-center px-4 py-2 bg-red-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-red-500 active:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition ease-in-out duration-150 px-4">
            <i class="fa-solid fa-print"></i>&nbsp;Imprimir Tabla
        </a><br><br>
        <div style="overflow:auto" id="tabla">
            <table class="w-full">
                <thead class="bg-gray-200">
                    <tr>
                        <th class="px-6 py-2 text-xs text-gray-500" colspan="6"><?php echo e($customer->code); ?> - <?php echo e($customer->lastname); ?>, <?php echo e($customer->name); ?></th> 
                    </tr>
                    <tr>
                        <th class="px-6 py-2 text-xs text-gray-500">No.</th>
                        <th class="px-6 py-2 text-xs text-gray-500">Fecha</th>
                        <th class="px-6 py-2 text-xs text-gray-500">Cuota Capital</th>
                        <th class="px-6 py-2 text-xs text-gray-500">Interes</th>
                        <th class="px-6 py-2 text-xs text-gray-500">Total</th>
                        <th class="px-6 py-2 text-xs text-gray-500">Saldo Capital</th>
                    </tr>
                </thead>
                <tbody class="bg-white">
                    <tr>
                        <td class="px-6 py-2 text-xs text-gray-500" colspan="5"></td>
                        <td class="px-6 py-2 text-xs text-gray-500">
                            <?php echo e(number_format($initial_capital,2,'.',',')); ?>

                        </td>
                    </tr>
                    <?php
                        $total_interes=0;
                        $total_a_pagar=0;
                    ?>
                    <!--[if BLOCK]><![endif]--><?php if($policy_id==1): ?>        
                        <?php
                            $cuota = $amortization->cuota_nivelada($initial_capital,$interest_id,$time_limit_id);
                            $interes = $interest->find($interest_id);
                            $plazo = $timelimit->find($time_limit_id);
                            $saldo_capital = $initial_capital;
                            $fecha=date('Y-m-d');
                        ?>
                        <!--[if BLOCK]><![endif]--><?php for($i=1; $i <= $plazo->name; $i++): ?>
                            <?php
                                $fecha = date('Y-m-d', strtotime('+1 month', strtotime($fecha)));
                                $interes_cuota = $saldo_capital * ($interes->name / 12 / 100);
                                $capital_cuota = $cuota - $interes_cuota;
                                $saldo_capital = $saldo_capital - $capital_cuota;
                                $total_interes=$total_interes + $interes_cuota;
                                $total_a_pagar=$total_a_pagar + $cuota;
                            ?>
                            <tr>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e($i); ?>

                                </td>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e(date('d/m/Y',strtotime($fecha))); ?>

                                </td>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e(number_format($capital_cuota,2,'.',',')); ?>

                                </td>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e(number_format($interes_cuota,2,'.',',')); ?>

                                </td>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e(number_format($cuota,2,'.',',')); ?>

                                </td>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e(number_format($saldo_capital,2,'.',',')); ?>

                                </td>
                            </tr>
                        <?php endfor; ?> <!--[if ENDBLOCK]><![endif]-->
                    <?php elseif($policy_id==2): ?>
                        <?php
                            $interes = $interest->find($interest_id);
                            $plazo = $timelimit->find($time_limit_id);
                            $saldo_capital = $initial_capital;
                            $fecha=date('Y-m-d');
                        ?>
                        <!--[if BLOCK]><![endif]--><?php for($i=1; $i <= $plazo->name; $i++): ?>
                            <?php
                                $fecha = date('Y-m-d', strtotime('+1 month', strtotime($fecha)));
                                $interes_cuota = ((($saldo_capital * ($interes->name / 100))/365)*31);
                                $capital_cuota = $initial_capital/$plazo->name;
                                $saldo_capital = $saldo_capital - $capital_cuota;
                                $cuota=$interes_cuota+$capital_cuota;
                                $total_interes=$total_interes + $interes_cuota;
                                $total_a_pagar=$total_a_pagar + $cuota;
                            ?>
                            <tr>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e($i); ?>

                                </td>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e(date('d/m/Y',strtotime($fecha))); ?>

                                </td>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e(number_format($capital_cuota,2,'.',',')); ?>

                                </td>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e(number_format($interes_cuota,2,'.',',')); ?>

                                </td>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e(number_format($cuota,2,'.',',')); ?>

                                </td>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e(number_format($saldo_capital,2,'.',',')); ?>

                                </td>
                            </tr>
                        <?php endfor; ?> <!--[if ENDBLOCK]><![endif]-->
                    <?php else: ?>
                        <?php
                            $interes = $interest->find($interest_id);
                            $plazo = $timelimit->find($time_limit_id);
                            $saldo_capital = $initial_capital;
                            $capital_cuota = $initial_capital / $plazo->name;
                            $interes_cuota = (((((($saldo_capital * ($interes->name / 100))/365)*31)*$plazo->name))/$plazo->name);
                            $fecha=date('Y-m-d');
                        ?>
                        <!--[if BLOCK]><![endif]--><?php for($i=1; $i <= $plazo->name; $i++): ?>
                            <?php
                                $fecha = date('Y-m-d', strtotime('+1 month', strtotime($fecha)));
                                $saldo_capital = $saldo_capital - $capital_cuota;
                                $cuota=$interes_cuota+$capital_cuota;
                                $total_interes=$total_interes + $interes_cuota;
                                $total_a_pagar=$total_a_pagar + $cuota;
                            ?>
                            <tr>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e($i); ?>

                                </td>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e(date('d/m/Y',strtotime($fecha))); ?>

                                </td>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e(number_format($capital_cuota,2,'.',',')); ?>

                                </td>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e(number_format($interes_cuota,2,'.',',')); ?>

                                </td>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e(number_format($cuota,2,'.',',')); ?>

                                </td>
                                <td class="px-6 py-2 text-xs text-gray-500">
                                    <?php echo e(number_format($saldo_capital,2,'.',',')); ?>

                                </td>
                            </tr>
                        <?php endfor; ?> <!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                </tbody>
                <tfooter>
                    <tr>
                        <th class="px-6 py-2 text-xs text-gray-500"></th>
                        <th class="px-6 py-2 text-xs text-gray-500"></th>
                        <th class="px-6 py-2 text-xs text-gray-500 text-right">Total:</th>
                        <th class="px-6 py-2 text-xs text-gray-500"><?php echo e(number_format($total_interes,2,'.',',')); ?></th>
                        <th class="px-6 py-2 text-xs text-gray-500"><?php echo e(number_format($total_a_pagar,2,'.',',')); ?></th>
                        <th class="px-6 py-2 text-xs text-gray-500"></th>
                    </tr>
                </tfooter>
            </table>
        </div>
        <div class="bg-gray-50 px-4 py-3 sm:px-6 text-right">
            <?php if (isset($component)) { $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['wire:click' => 'save','class' => 'mt-4 mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'save','class' => 'mt-4 mb-4']); ?>
                Registrar Solicitud de Crédito
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $attributes = $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $component = $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
        </div>
    <?php else: ?>
        <h4 class="py-4">Debe llenar todos los datos anteriores.</h4>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    
</div>
<?php /**PATH /home3/kodbli/public_html/sistemas/creditos/inveria/resources/views/livewire/amortization-preview-component.blade.php ENDPATH**/ ?>