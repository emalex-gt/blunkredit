<div>
    
    <a wire:click="$set('open',true)" class="cursor-pointer">
        <i class="fa-solid fa-circle-info"></i>
    </a>

    
        <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['wire:model' => 'open']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'open']); ?>
            <div>
                <div class="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
                    <div class="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg">
                        <div class="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
                            <div>
                                <div class="mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left">
                                    <h3 class="text-base font-semibold leading-6 text-gray-900" id="modal-title">Detalles</h3>
                                    <div class="mt-2">
                                        <b>Fecha: </b> <?php echo e(date('Y-m-d H:i', strtotime($statement->date))); ?>

                                    </div>
                                    <div class="mt-2">
                                        <b>Monto: </b> Q.<?php echo e(number_format(($statement->credit + $statement->debit),2,'.',',')); ?>

                                    </div>
                                    <!--[if BLOCK]><![endif]--><?php if($statement->type < 7): ?>
                                        <!--[if BLOCK]><![endif]--><?php if($statement->type==2): ?>
                                            <div class="mt-2 bg-gray-200 p-2">
                                                <b>Aporte de</b>
                                            </div>
                                            <div class="border-gray-200 border-2 p-2">
                                                <div class="mt-2">
                                                    <!--[if BLOCK]><![endif]--><?php if($fundstatementinvestor->investor->type==1): ?>
                                                        <b>Dueño: </b> 
                                                    <?php else: ?>
                                                        <b>Inversor: </b> 
                                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                                    <?php echo e($fundstatementinvestor->investor->dpi); ?> - <?php echo e($fundstatementinvestor->investor->name); ?>, <?php echo e($fundstatementinvestor->investor->lastname); ?>

                                                </div>
                                                <div class="mt-2">
                                                    <b>Recibo: </b> <?php echo e($fundstatementdetail->receipt_number); ?>

                                                </div>
                                            </div>
                                        <?php elseif($statement->type==3): ?>
                                            <div class="mt-2 bg-gray-200 p-2">
                                                <b>Aporte General</b>
                                            </div>
                                            <div class="border-gray-200 border-2 p-2">
                                                <div class="mt-2">
                                                    <b>Recibo: </b> <?php echo e($fundstatementdetail->receipt_number); ?>

                                                </div>
                                            </div>
                                        <?php elseif($statement->type==4): ?>
                                            <div class="mt-2 bg-gray-200 p-2">
                                                <b>Desembolso a</b>
                                            </div>
                                            <div class="border-gray-200 border-2 p-2">
                                                <div class="mt-2">
                                                    <b>Crédito: </b> <?php echo e($credit->code); ?>

                                                </div>
                                                <div class="mt-2">
                                                    <b>Cliente: </b> <?php echo e($credit->customer->lastname); ?>, <?php echo e($credit->customer->name); ?>

                                                </div>
                                            </div>
                                        <?php elseif($statement->type==5): ?>
                                            <div class="mt-2 bg-gray-200 p-2">
                                                <b>Abono de</b>
                                            </div>
                                            <div class="border-gray-200 border-2 p-2">
                                                <div class="mt-2">
                                                    <b>Crédito: </b> <?php echo e($payment->credit->code); ?>

                                                </div>
                                                <div class="mt-2">
                                                    <b>Cliente: </b> <?php echo e($payment->credit->customer->lastname); ?>, <?php echo e($payment->credit->customer->name); ?>

                                                </div>
                                                <div class="mt-2">
                                                    <b>Recibo: </b> <?php echo e($fundstatementdetail->receipt_number); ?>

                                                </div>
                                            </div>
                                        <?php elseif($statement->type==6): ?>
                                            <div class="mt-2">
                                                <b>Recibo: </b> <?php echo e($fundstatementdetail->receipt_number); ?>

                                            </div>
                                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                        <div class="mt-2">
                                            <b>Observación: </b> <?php echo e($fundstatementdetail->info); ?>

                                        </div>
                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                    <div class="mt-2">
                                        <b>Usuario Registra: </b> <?php echo e($statement->created_by->name); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bg-gray-50 px-4 py-3 sm:px-6 text-right">
                            <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['wire:click' => '$set(\'open\',false)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => '$set(\'open\',false)']); ?>
                                Cerrar
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    

</div>
<?php /**PATH /home3/kodbli/public_html/sistemas/creditos/inveria/resources/views/livewire/fund-statement-info-component.blade.php ENDPATH**/ ?>