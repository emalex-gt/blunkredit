<div>
    
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Buscar Créditos')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginal7d55ee3ed983a76438782c315d95e08b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d55ee3ed983a76438782c315d95e08b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.principal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('principal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

        <div class="px-6 py-4">
            <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['class' => 'w-full','placeholder' => '&#xF002; Buscar por Cliente o No. de Crédito','type' => 'text','wire:model.live' => 'search','style' => 'font-family:Arial, FontAwesome']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full','placeholder' => '&#xF002; Buscar por Cliente o No. de Crédito','type' => 'text','wire:model.live' => 'search','style' => 'font-family:Arial, FontAwesome']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
        </div>

        <table class="w-full" wire:key="table">
            <thead class="bg-gray-200">
                <tr>
                    <th class="px-6 py-2 text-xs text-gray-500">CODIGO</th>
                    <th class="px-6 py-2 text-xs text-gray-500">DPI</th>
                    <th class="px-6 py-2 text-xs text-gray-500">NOMBRE</th>
                    <th class="px-6 py-2 text-xs text-gray-500">TELÉFONO</th>
                    <th class="px-6 py-2 text-xs text-gray-500">EMAIL</th>
                </tr>
            </thead>
            <tbody class="bg-white">
                <!--[if BLOCK]><![endif]--><?php if(count($customers)): ?>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr wire:key="customer-<?php echo e($customer->id); ?>">
                            <table class="w-full" wire:key="table-<?php echo e($customer->id); ?>">
                            <tbody>
                                <tr class="border-b-2 bg-gray-800">
                                    <td class="px-6 py-4 text-md text-white text-center"><?php echo e($customer->code); ?></td>
                                    <td class="px-6 py-4 text-md text-white text-center"><?php echo e($customer->dpi); ?></td>
                                    <td class="px-6 py-4 text-md text-white text-center"><?php echo e($customer->lastname); ?>, <?php echo e($customer->name); ?></td>
                                    <td class="px-6 py-4 text-md text-white text-center"><a class="text-gray-400" href="tel:<?php echo e($customer->phone); ?>"><?php echo e($customer->phone); ?></a></td>
                                    <td class="px-6 py-4 text-md text-white text-center"><a class="text-gray-400" href="mailto:<?php echo e($customer->email); ?>"><?php echo e($customer->email); ?></a></td>
                                </tr>
                                <tr class="border-b-2">
                                    <td colspan="5"></td>
                                </tr>
                                <tr class="border-b-2">
                                    <td colspan="5">
                                        <div class="px-4 py-5 text-left" id="show-<?php echo e($customer->id); ?>">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('new-credit')): ?>
                                                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('credit-create-component',['customer'=>$customer]);

$__html = app('livewire')->mount($__name, $__params, $customer->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                            <?php endif; ?>
                                            <h2 class="block py-4 text-center">CRÉDITOS</h3>
                                            <!--[if BLOCK]><![endif]--><?php if(count($customer->credits)): ?>
                                                <table class="w-full">
                                                    <thead>
                                                        <tr class="border-gray-200 border-b-2">
                                                            <th class="px-6 py-2 text-xs text-gray-500">CODIGO</th>
                                                            <th class="px-6 py-2 text-xs text-gray-500">FONDO</th>
                                                            <th class="px-6 py-2 text-xs text-gray-500">TECNOLOGÍA</th>
                                                            <th class="px-6 py-2 text-xs text-gray-500">GARANTÍA</th>
                                                            <th class="px-6 py-2 text-xs text-gray-500">CAPITAL INICIAL</th>
                                                            <th class="px-6 py-2 text-xs text-gray-500">CAPITAL PENDIENTE</th>
                                                            <th class="px-6 py-2 text-xs text-gray-500">ESTADO</th>
                                                            <th class="px-6 py-2 text-xs text-gray-500"></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $customer->credits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr class="border-gray-200 border-b-2" wire:key="credit-<?php echo e($credit->id); ?>">
                                                                <td class="px-6 py-4 text-md text-gray-500 text-center"><?php echo e($credit->code); ?></td>
                                                                <td class="px-6 py-4 text-md text-gray-500 text-center"><?php echo e($credit->fund->name); ?></td>
                                                                <td class="px-6 py-4 text-md text-gray-500 text-center"><?php echo e($credit->tecnology->name); ?></td>
                                                                <td class="px-6 py-4 text-md text-gray-500 text-center"><?php echo e($credit->guarantee->name); ?></td>
                                                                <td class="px-6 py-4 text-md text-gray-500 text-center">Q.<?php echo e(number_format($credit->initial_credit_capital,2,'.',',')); ?></td>
                                                                <td class="px-6 py-4 text-md text-gray-500 text-center">Q.<?php echo e(number_format($credit->pending_credit_capital,2,'.',',')); ?></td>
                                                                <td class="px-6 py-4 text-md text-gray-500 text-center">
                                                                    <!--[if BLOCK]><![endif]--><?php switch($credit->status):
                                                                        case (1): ?>
                                                                            <span class="px-1 py-1 rounded" style="background-color:yellow">Registrado</span>
                                                                            <?php break; ?>
                                                                        <?php case (2): ?>
                                                                            <span class="px-1 py-1 rounded text-white" style="background-color:orange">Autorizado</span>
                                                                            <?php break; ?>
                                                                        <?php case (3): ?>
                                                                            <span class="px-1 py-1 rounded text-white" style="background-color:green">Activo</span>
                                                                            <?php break; ?>
                                                                        <?php case (4): ?>
                                                                            <span class="px-1 py-1 rounded text-white" style="background-color:red">Finalizado</span>
                                                                            <?php break; ?>
                                                                    <?php endswitch; ?> <!--[if ENDBLOCK]><![endif]-->
                                                                </td>
                                                                <td class="px-6 py-4 text-md text-gray-500 text-center">
                                                                    <a href="<?php echo e(route('credito',$credit->id)); ?>" class="inline-block px-1 py-1 bg-gray-800 border border-transparent rounded-md text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition">
                                                                        <small><i class="fa-solid fa-eye"></i></small>
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                                                    </tbody>
                                                </table>
                                            <?php else: ?>
                                                <h4 class="block text-center">No posee créditos</h4>
                                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    </td>
                                </tr>
                                <tr class="border-gray-200 border-b-2">
                                    <td colspan="5"></td>
                                </tr>
                            </tbody>
                            </table>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                <?php else: ?>
                    <tr>
                        <td colspan="3" class="px-6 py-4 text-sm text-gray-500 text-center text-lg">
                            No existen registros
                        </td>
                    </tr>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>

        <!--[if BLOCK]><![endif]--><?php if(count($customers)): ?>
            <!--[if BLOCK]><![endif]--><?php if($customers->hasPages()): ?>
                <div class="px-6 py-3">
                    <?php echo e($customers->links()); ?>

                </div>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d55ee3ed983a76438782c315d95e08b)): ?>
<?php $attributes = $__attributesOriginal7d55ee3ed983a76438782c315d95e08b; ?>
<?php unset($__attributesOriginal7d55ee3ed983a76438782c315d95e08b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d55ee3ed983a76438782c315d95e08b)): ?>
<?php $component = $__componentOriginal7d55ee3ed983a76438782c315d95e08b; ?>
<?php unset($__componentOriginal7d55ee3ed983a76438782c315d95e08b); ?>
<?php endif; ?>
    <?php $__env->startPush('js'); ?>
        <script>
            $( ".button-toggle" ).on( "click", function() {
                var refid = $(this).attr('ref-id');
                $( "#show-" + refid ).toggle( "slow" );
            });
        </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH /home3/kodbli/public_html/sistemas/creditos/inveria/resources/views/livewire/credits-component.blade.php ENDPATH**/ ?>