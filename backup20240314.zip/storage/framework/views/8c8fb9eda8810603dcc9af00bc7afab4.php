<div class="max-w-screen-xl mx-auto w-full">
    <div class="container flex justify-center mx-auto">
            <div class="w-full"> 
                <?php echo e($slot); ?>

            </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\blunkredit\resources\views/components/table.blade.php ENDPATH**/ ?>