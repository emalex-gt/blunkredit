<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Datos de Crédito - Regla Modificada</title>
        <style>
        body{
            font-size:12px;
        }
        h1{
            text-align: center;
            text-transform: uppercase;
            font-size:16px;
        }
        .borde{
            border:1px solid #000;
            padding:20px;
        }
        table{
            width:100%;
            border-spacing: 5px;
            border-collapse: collapse;
        }
        th{
            text-align:center;
            border-bottom:1px solid #000;
        }
        td{
            text-align:right;
        }
    </style>
    </head>
    <body onload="window.print()">
        <center><img src="<?php echo e(asset('build/assets/img/logo.png')); ?>" height="50px"/></center>
        <h1>INVERIA PRESTAMOS</h1>
        <h4>Fecha y Hora de Impresión: <?php echo e(date('d/m/Y H:i')); ?></h4>
        <div class="borde">
            <h1>DATOS GENERAL DEL CRÉDITO</h1>
            <table>
                <tr>
                    <td style="text-align:left">Tecnología:</td>
                    <td style="text-align:left" colspan="3"><?php echo e($credit->tecnology->name); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Nombre del Usuario:</td>
                    <td style="text-align:left" colspan="3"><?php echo e($credit->customer->name); ?> <?php echo e($credit->customer->lastname); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Dirección:</td>
                    <td style="text-align:left" colspan="3"><?php echo e($credit->customer->address); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Nombre Fondo:</td>
                    <td style="text-align:left"><?php echo e($credit->fund->name); ?></td>
                    <td style="text-align:left">NIT:</td>
                    <td style="text-align:left"></td>
                </tr>
                <tr>
                    <td style="text-align:left">Código de Usuario:</td>
                    <td style="text-align:left"><?php echo e($credit->customer->code); ?></td>
                    <td style="text-align:left">Número de Crédito:</td>
                    <td style="text-align:left"><?php echo e($credit->code); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Fecha de Entrega:</td>
                    <td style="text-align:left"><?php echo e(date('d/m/Y',strtotime($credit->expended_at))); ?></td>
                    <td style="text-align:left">Fecha de Vencim.:</td>
                    <td style="text-align:left"><?php echo e(date('d/m/Y',strtotime($credit->amortizacion_schedule->sortDesc()->first()->share_date))); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Plazo en Meses:</td>
                    <td style="text-align:left"><?php echo e($credit->time_limit->name); ?></td>
                    <td style="text-align:left">Capital:</td>
                    <td style="text-align:left"><?php echo e(number_format($credit->initial_credit_capital,2,'.',',')); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Tasa de Interés:</td>
                    <td style="text-align:left"><?php echo e($credit->interest->name); ?>%</td>
                    <td style="text-align:left">Política:</td>
                    <td style="text-align:left"><?php echo e($credit->policy->name); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Cédula/DPI:</td>
                    <td style="text-align:left"><?php echo e($credit->customer->dpi); ?></td>
                    <td style="text-align:left">Usuario Operó</td>
                    <td style="text-align:left"><?php echo e($credit->created_by->id); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Asesor:</td>
                    <td style="text-align:left"><?php echo e($credit->created_by->name); ?></td>
                    <td style="text-align:left"></td>
                    <td style="text-align:left"></td>
                </tr>
                <tr>
                    <td style="text-align:left">Garantía:</td>
                    <td style="text-align:left"><?php echo e($credit->guarantee->name); ?></td>
                    <td style="text-align:left">Primer Pago:</td>
                    <td style="text-align:left"><?php echo e(date('d/m/Y',strtotime($credit->amortizacion_schedule->sort()->first()->share_date))); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Línea de Crédito:</td>
                    <td style="text-align:left"><?php echo e($credit->credit_line->name); ?></td>
                    <td style="text-align:left">Cuota:</td>
                    <td style="text-align:left"><?php echo e(number_format($credit->amortizacion_schedule->sort()->first()->capital,2,'.',',')); ?></td>
                </tr>
            </table>
        </div>
        <h1>REGLA DE PAGO MODIFICADA</h1>
        <h4>PAGOS REALIZADOS</h4>
        <table>
            <tr>
                <th></th>
                <th>Fecha<br>de Pago</th>
                <th>Fecha<br>de Cálculo</th>
                <th>Tipo<br>Trn.</th>
                <th>No.<br>Trn</th>
                <th>Días</th>
                <th>Cuota<br>Capital</th>
                <th>Cuota<br>Interés</th>
                <th>Cuota<br>Mora</th>
                <th>Cuota<br>Total</th>
                <th>Saldo<br>Capital</th>
                <th>Saldo<br>Interés</th>
                <th>Saldo<br>Total</th>
                <th>CP</th>
                <th>Usuario</th>
            </tr>
            <?php
                $fecha_anterior=$credit->expended_at;
                $tot_dias=0;
                $tot_capital=0;
                $tot_interes=0;
                $tot_mora=0;
                $tot_total=0;             
            ?>
            <?php $__currentLoopData = $credit->amortizacion_schedule->where('total_payment','>',0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($table->number); ?></td>
                    <td style="text-align:center"><?php echo e(date('d/m/Y',strtotime($table->payment_date))); ?></td>
                    <td style="text-align:center"><?php echo e(date('d/m/Y',strtotime($table->share_date))); ?></td>
                    <td style="text-align:center">REI</td>
                    <td style="text-align:center"><?php echo e($table->id); ?></td>
                    <td style="text-align:center">
                        <?php
                            $date1 = new DateTime(date('Y-m-d',strtotime($fecha_anterior)));
                            $date2 = new DateTime(date('Y-m-d',strtotime($table->share_date)));
                            $diff = $date1->diff($date2);
                            $fecha_anterior=$table->share_date;
                        ?>
                        <?php echo e($diff->days); ?>

                    </td>
                    <td><?php echo e(number_format($table->capital,2,'.',',')); ?></td>
                    <td><?php echo e(number_format($table->interest,2,'.',',')); ?></td>
                    <td><?php echo e(number_format($table->delay,2,'.',',')); ?></td>
                    <td><?php echo e(number_format($table->total_payment,2,'.',',')); ?></td>
                    <td><?php echo e(number_format($table->capital_balance,2,'.',',')); ?></td>
                    <td><?php echo e(number_format($table->interest_balance,2,'.',',')); ?></td>
                    <td><?php echo e(number_format($table->total_balance,2,'.',',')); ?></td>
                    <td><?php echo e($table->payment_by->id); ?></td>
                    <td style="text-align:center"><?php echo e($table->payment_by->name); ?></td>
                    <?php
                        $tot_dias=$tot_dias+$diff->days;
                        $tot_capital=$tot_capital+$table->capital;
                        $tot_interes=$tot_interes+$table->interest;
                        $tot_mora=$tot_mora+$table->delay;
                        $tot_total=$tot_total+$table->total;
                    ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="4">Total Pagado</td>
                <td style="border-top:1px solid #000"></td>
                <td style="border-top:1px solid #000;text-align:center"><?php echo e($tot_dias); ?></td>
                <td style="border-top:1px solid #000"><?php echo e($tot_capital); ?></td>
                <td style="border-top:1px solid #000"><?php echo e($tot_interes); ?></td>
                <td style="border-top:1px solid #000"><?php echo e($tot_mora); ?></td>
                <td style="border-top:1px solid #000"><?php echo e($tot_total); ?></td>
                <td style="border-top:1px solid #000"></td>
                <td style="border-top:1px solid #000"></td>
                <td style="border-top:1px solid #000"></td>
                <td style="border-top:1px solid #000"></td>
                <td style="border-top:1px solid #000"></td>
            </tr>
        </table>
        <h4>SALDO A LA FECHA</h4>
        <h4>DIAS DE ATRASO EN EL PAGO: <?php echo e($credit->days_delayed); ?></h4>
        <center>
            <table style="width:75%">
                <tr>
                    <th style="border-top:1px solid #000;border-left:1px solid #000;border-bottom:0">Fecha Cálculo</th>
                    <th style="border-top:1px solid #000;border-left:1px solid #000;border-bottom:0">Capital</th>
                    <th style="border-top:1px solid #000;border-left:1px solid #000;border-bottom:0">Interés</th>
                    <th style="border-top:1px solid #000;border-left:1px solid #000;border-bottom:0">Mora</th>
                    <th style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;border-bottom:0">Total a Pagar</th>
                </tr>
                <tr>
                    <td style="border-left:1px solid #000;text-align:center"><?php echo e(date('d/m/Y')); ?></td>
                    <td style="border-left:1px solid #000;text-align:center"><?php echo e(number_format($credit->amortizacion_schedule->where('total_payment',0)->first()->capital,2,'.',',')); ?></td>
                    <td style="border-left:1px solid #000;text-align:center"><?php echo e(number_format($credit->amortizacion_schedule->where('total_payment',0)->first()->interest,2,'.',',')); ?></td>
                    <td style="border-left:1px solid #000;text-align:center"><?php echo e(number_format($credit->amortizacion_schedule->where('total_payment',0)->first()->delay,2,'.',',')); ?></td>
                    <td style="border-right:1px solid #000;border-left:1px solid #000;text-align:center"><?php echo e(number_format($credit->amortizacion_schedule->where('total_payment',0)->first()->total,2,'.',',')); ?></td>
                </tr>
                <tr>
                    <td style="border-bottom:1px solid #000;border-left:1px solid #000;text-align:center">Cancelación Anticipada</td>
                    <td style="border-bottom:1px solid #000;border-left:1px solid #000;text-align:center"><?php echo e(number_format($credit->amortizacion_schedule->where('total_payment',0)->first()->capital,2,'.',',')); ?></td>
                    <td style="border-bottom:1px solid #000;border-left:1px solid #000;text-align:center"><?php echo e(number_format($credit->amortizacion_schedule->where('total_payment',0)->first()->interest,2,'.',',')); ?></td>
                    <td style="border-bottom:1px solid #000;border-left:1px solid #000;text-align:center">0.00</td>
                    <td style="border-bottom:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;text-align:center">
                        <?php
                            $tota=$credit->amortizacion_schedule->where('total_payment',0)->first()->total;
                            $delay=$credit->amortizacion_schedule->where('total_payment',0)->first()->delay;
                            $tot=$tota-$delay;
                        ?>
                        <?php echo e(number_format(($tot),2,'.',',')); ?>

                    </td>
                </tr>
            </table>
        </center>
        <h4>PAGOS PENDIENTES</h4>
        <table>
            <tr>
                <th></th>
                <th>Fecha Prevista<br>de Pago</th>
                <th>Días</th>
                <th>Cuota<br>Capital</th>
                <th>Cuota<br>Interés</th>
                <th>Cuota<br>Mora</th>
                <th>Cuota<br>Total</th>
                <th>Saldo<br>Capital</th>
                <th>Saldo<br>Interés</th>
                <th>Saldo<br>Total</th>
            </tr>
            <?php
                $tot_dias_p=0;
                $tot_capital_p=0;
                $tot_interes_p=0;
                $tot_mora_p=0;
                $tot_total_p=0;             
            ?>
            <?php $__currentLoopData = $credit->amortizacion_schedule->where('total_payment',0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($table->number); ?></td>
                    <td style="text-align:center"><?php echo e(date('d/m/Y',strtotime($table->share_date))); ?></td>
                    <td style="text-align:center">
                        <?php
                            $date1 = new DateTime(date('Y-m-d',strtotime($fecha_anterior)));
                            $date2 = new DateTime(date('Y-m-d',strtotime($table->share_date)));
                            $diff = $date1->diff($date2);
                            $fecha_anterior=$table->share_date;
                        ?>
                        <?php echo e($diff->days); ?>

                    </td>
                    <td><?php echo e(number_format($table->capital,2,'.',',')); ?></td>
                    <td><?php echo e(number_format($table->interest,2,'.',',')); ?></td>
                    <td><?php echo e(number_format($table->delay,2,'.',',')); ?></td>
                    <td><?php echo e(number_format($table->total,2,'.',',')); ?></td>
                    <td><?php echo e(number_format($table->capital_balance,2,'.',',')); ?></td>
                    <td><?php echo e(number_format($table->interest_balance,2,'.',',')); ?></td>
                    <td><?php echo e(number_format($table->total_balance,2,'.',',')); ?></td>
                    <?php
                        $tot_dias=$tot_dias+$diff->days;
                        $tot_capital=$tot_capital+$table->capital;
                        $tot_interes=$tot_interes+$table->interest;
                        $tot_mora=$tot_mora+$table->delay;
                        $tot_total=$tot_total+$table->total;
                        $tot_dias_p=$tot_dias_p+$diff->days;
                        $tot_capital_p=$tot_capital_p+$table->capital;
                        $tot_interes_p=$tot_interes_p+$table->interest;
                        $tot_mora_p=$tot_mora_p+$table->delay;
                        $tot_total_p=$tot_total_p+$table->total;
                    ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="2">Total Pagado</td>
                <td style="border-top:1px solid #000"><?php echo e($tot_dias_p); ?></td>
                <td style="border-top:1px solid #000;text-align:center"><?php echo e($tot_capital_p); ?></td>
                <td style="border-top:1px solid #000"><?php echo e($tot_interes_p); ?></td>
                <td style="border-top:1px solid #000"><?php echo e($tot_mora_p); ?></td>
                <td style="border-top:1px solid #000"><?php echo e($tot_total_p); ?></td>
                <td style="border-top:1px solid #000"></td>
                <td style="border-top:1px solid #000"></td>
                <td style="border-top:1px solid #000"></td>
            </tr>
            <tr>
                <td colspan="2">TOTAL GENERAL</td>
                <td><?php echo e($tot_dias); ?></td>
                <td style="text-align:center"><?php echo e($tot_capital); ?></td>
                <td><?php echo e($tot_interes); ?></td>
                <td><?php echo e($tot_mora); ?></td>
                <td><?php echo e($tot_total); ?></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
        </table>
    </body>
</html><?php /**PATH C:\xampp\htdocs\blunkredit\resources\views/pdf/regla-modificada.blade.php ENDPATH**/ ?>