<div>
    
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Crédito No. ')); ?><?php echo e($credit->code); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginal7d55ee3ed983a76438782c315d95e08b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d55ee3ed983a76438782c315d95e08b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.principal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('principal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <table class="w-full">
                <tr>
                <td class="px-4" style="vertical-align: top;">
                    <div class="justify-center p-4 text-center sm:items-center sm:p-0">
                        <div class="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full">
                            <div class="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
                                <div>
                                    <div class="mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left">
                                        <h2 class="text-base font-semibold leading-6 text-gray-900">Datos del Cliente</h2>
                                        <hr/>
                                        <div class="mt-2">
                                            <b>Código:</b> <?php echo e($credit->customer->code); ?><br>
                                            <b>Nombre:</b> <?php echo e($credit->customer->lastname); ?>, <?php echo e($credit->customer->name); ?><br>
                                            <b>DPI:</b> <?php echo e($credit->customer->dpi); ?><br>
                                            <b>Dirección:</b> <?php echo e($credit->customer->address); ?><br>
                                            <b>Email:</b> <a href="mailto:<?php echo e($credit->customer->email); ?>"><?php echo e($credit->customer->email); ?></a><br>
                                            <b>Teléfono:</b> <a href="tel:<?php echo e($credit->customer->phone); ?>"><?php echo e($credit->customer->phone); ?></a><br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                <td class="px-4" style="vertical-align: top;">
                    <div class="justify-center p-4 text-center sm:items-center sm:p-0">
                        <div class="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full">
                            <div class="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
                                <div>
                                    <div class="mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left">
                                        <h2 class="text-base font-semibold leading-6 text-gray-900">Datos del Crédito</h2>
                                        <hr/>
                                        <div class="mt-2">
                                            <b>Estado:</b>
                                            <!--[if BLOCK]><![endif]--><?php switch($credit->status):
                                                case (1): ?>
                                                    <span class="px-1 py-1 rounded" style="background-color:yellow">Registrado</span>
                                                    <?php break; ?>
                                                <?php case (2): ?>
                                                    <span class="px-1 py-1 rounded text-white" style="background-color:orange">Autorizado</span>
                                                    <?php break; ?>
                                                <?php case (3): ?>
                                                    <span class="px-1 py-1 rounded text-white" style="background-color:green">Activo</span>
                                                    <?php break; ?>
                                                <?php case (4): ?>
                                                    <span class="px-1 py-1 rounded text-white" style="background-color:red">Finalizado</span>
                                                    <?php break; ?>
                                            <?php endswitch; ?> <!--[if ENDBLOCK]><![endif]-->
                                            <br>
                                            <b>Tecnología:</b> <?php echo e($credit->tecnology->name); ?><br>
                                            <b>Política:</b> <?php echo e($credit->policy->name); ?><br>
                                            <b>Plazo:</b> <?php echo e($credit->time_limit->name); ?> meses<br>
                                            <b>Interés:</b> <?php echo e($credit->interest->name); ?>%<br>
                                            <b>Capital:</b> Q.<?php echo e(number_format($credit->initial_credit_capital,2,'.',',')); ?><br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                <td class="px-4" style="vertical-align: top;">
                    <div class="justify-center p-4 text-center sm:items-center sm:p-0">
                        <div class="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full">
                            <div class="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
                                <div>
                                    <div class="mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left">
                                        <h2 class="text-base font-semibold leading-6 text-gray-900">Datos del Expediente</h2>
                                        <hr/>
                                        <div class="mt-2">
                                            <?php if($credit->status>2): ?>
                                                <b>Fondo:</b> <?php echo e($credit->fund->name); ?><br>
                                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                            <b>Línea de Crédito:</b> <?php echo e($credit->credit_line->name); ?><br>
                                            <b>Garantía:</b> <?php echo e($credit->guarantee->name); ?><br>
                                            <b>Expediente:</b> <?php echo e($credit->file_number); ?><br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
                <?php if($credit->status>2): ?>
                    <tr>
                        <td class="px-4" style="vertical-align: top;">
                            <div class="justify-center p-4 text-center sm:items-center sm:p-0 mt-4">
                                <div class="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full">
                                    <div class="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
                                        <div>
                                            <div class="mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left">
                                                <h2 class="text-base font-semibold leading-6 text-gray-900">Gastos Administrativos</h2>
                                                <hr/>
                                                <div class="mt-2">
                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $credit->administrative_expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $administrative_expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <b>
                                                            <!--[if BLOCK]><![endif]--><?php switch($administrative_expense->type):
                                                                case (1): ?>
                                                                    Desembolso
                                                                    <?php break; ?>
                                                                <?php case (2): ?>
                                                                    Contrato
                                                                    <?php break; ?>
                                                                <?php case (3): ?>
                                                                    Traspaso
                                                                    <?php break; ?>
                                                            <?php endswitch; ?> <!--[if ENDBLOCK]><![endif]-->
                                                        </b> Q.<?php echo e(number_format($administrative_expense->amount,2,'.',',')); ?><br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td class="px-4" style="vertical-align: top;">
                            <div class="justify-center p-4 text-center sm:items-center sm:p-0 mt-4">
                                <div class="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full">
                                    <div class="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
                                        <div>
                                            <div class="mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left">
                                                <h2 class="text-base font-semibold leading-6 text-gray-900">Estado Actual</h2>
                                                <hr/>
                                                <div class="mt-2">
                                                    <!--[if BLOCK]><![endif]--><?php if($credit->policy_id==1): ?>
                                                        <b>Cuota:</b> Q.<?php echo e(number_format($credit->share,2,'.',',')); ?><br>
                                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                                    <b>Capital Pendiente:</b> Q.<?php echo e(number_format($credit->pending_credit_capital,2,'.',',')); ?><br>
                                                    <hr/>
                                                    <b>Capital Pagado:</b> Q.<?php echo e(number_format($credit->amortized_credit_capital,2,'.',',')); ?><br>
                                                    <b>Interés Pagado:</b> Q.<?php echo e(number_format($credit->interest_paid,2,'.',',')); ?><br>
                                                    <b>Mora Pagada:</b> Q.<?php echo e(number_format($credit->delay_paid,2,'.',',')); ?><br>
                                                    <b>Total Pagado:</b> Q.<?php echo e(number_format($credit->total_paid,2,'.',',')); ?><br>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td class="px-4" style="vertical-align: top;">
                            <div class="justify-center p-4 text-center sm:items-center sm:p-0 mt-4">
                                <div class="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full">
                                    <div class="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
                                        <div>
                                            <div class="mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left">
                                                <h2 class="text-base font-semibold leading-6 text-gray-900">Otros Datos</h2>
                                                <hr/>
                                                <div class="mt-2">
                                                    <b>Registrado:</b> <?php echo e($credit->created_by->name); ?> - <?php echo e(date('d/m/Y H:i',strtotime($credit->created_at) )); ?><br>
                                                    <b>Autorizado:</b> <?php echo e($credit->authorized_by->name); ?> - <?php echo e(date('d/m/Y H:i',strtotime($credit->authorized_at) )); ?><br>
                                                    <b>Desembolsado:</b> <?php echo e($credit->expended_by->name); ?> - <?php echo e(date('d/m/Y H:i',strtotime($credit->expended_at) )); ?><br>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('report-datos')): ?>
                                <div class="py-4 text-right">
                                    <a target="_blank" class="inline-flex items-center justify-center px-4 py-2 bg-red-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-red-500 active:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition ease-in-out duration-150 px-4" href="<?php echo e(route('regla-modificada',$credit->id)); ?>">
                                            Datos - Regla Modificada
                                    </a>
                                    <a target="_blank" class="inline-flex items-center justify-center px-4 py-2 bg-red-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-red-500 active:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition ease-in-out duration-150 px-4" href="<?php echo e(route('regla-general',$credit->id)); ?>">
                                            Datos - Regla Original
                                    </a>
                                </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                </tr>
            </table>
            <div class="justify-center p-4 text-center sm:items-center sm:p-0 mt-4 px-4">
                <div class="overflow-auto rounded-lg bg-white text-left shadow-xl sm:my-8 sm:w-full">
                    <div class="bg-white px-4 pb-4 pt-5 sm:p-6 sm:pb-4">
                        <div>
                            <div class="mt-3 text-center sm:ml-4 sm:mt-0 sm:text-left">
                                <h2 class="text-base font-semibold leading-6 text-gray-900">Tabla de Amortizaciones</h2>
                                <hr/>
                                <div class="mt-2">
                                    <table class="w-full">
                                        <thead class="bg-gray-200">
                                            <tr>
                                                <th class="px-6 py-2 text-center border">No.</th>
                                                <th class="px-6 py-2 text-center border">Fecha</th>
                                                <th class="px-6 py-2 text-center border">Cuota Capital</th>
                                                <th class="px-6 py-2 text-center border">Interes</th>
                                                <!--[if BLOCK]><![endif]--><?php if($credit->status == 3): ?>
                                                    <th class="px-6 py-2 text-center border">Mora</th>
                                                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                                <th class="px-6 py-2 text-center border">Total</th>
                                                <th class="px-6 py-2 text-center border">Saldo Capital</th>
                                                <!--[if BLOCK]><![endif]--><?php if($credit->status == 3): ?>
                                                    <th class="px-6 py-2 text-center border">Estado</th>
                                                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                            </tr>
                                        </thead>
                                        <tbody class="bg-white">
                                            <tr>
                                                <!--[if BLOCK]><![endif]--><?php if($credit->status == 3): ?>
                                                    <td class="border px-6 py-2" colspan="6"></td>
                                                <?php else: ?>
                                                    <td class="border px-6 py-2" colspan="5"></td>
                                                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                                <td class="border px-6 py-2 text-right">
                                                    <?php echo e(number_format($credit->initial_credit_capital,2,'.',',')); ?>

                                                </td>
                                            </tr>
                                            <?php
                                                $pad=0;
                                            ?>
                                            <?php $__currentLoopData = $credit->amortizacion_schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($table->days_delayed > 0): ?>
                                                    <tr style="background-color: red">
                                                <?php else: ?>
                                                    <tr>
                                                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                                    <td class="border px-6 py-2">
                                                        <?php echo e($table->number); ?>

                                                    </td>
                                                    <td class="border px-6 py-2">
                                                        <?php echo e(date('d/m/Y',strtotime($table->share_date))); ?>

                                                    </td>
                                                    <td class="border px-6 py-2 text-right">
                                                        <?php echo e(number_format($table->capital,2,'.',',')); ?>

                                                    </td>
                                                    <td class="border px-6 py-2 text-right">
                                                        <?php echo e(number_format($table->interest,2,'.',',')); ?>

                                                    </td>
                                                    <!--[if BLOCK]><![endif]--><?php if($credit->status == 3): ?>
                                                        <td class="border px-6 py-2 text-right">
                                                            <?php echo e(number_format($table->delay,2,'.',',')); ?>

                                                        </td>
                                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                                    <td class="border px-6 py-2 text-right">
                                                        <!--[if BLOCK]><![endif]--><?php if($table->total_payment==0): ?>
                                                            <?php echo e(number_format($table->total,2,'.',',')); ?>

                                                        <?php else: ?>
                                                            <?php echo e(number_format($table->total_payment,2,'.',',')); ?>

                                                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                                    </td>
                                                    <td class="border px-6 py-2 text-right">
                                                        <?php echo e(number_format($table->capital_balance,2,'.',',')); ?>

                                                    </td>
                                                    <!--[if BLOCK]><![endif]--><?php if($credit->status == 3): ?>
                                                        <td class="border px-6 py-2 text-right">
                                                            <?php if($table->total_payment==0 && $pad==0 && !count($table->prepayment)): ?>
                                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('collect-credit')): ?>
                                                                    <?php
                                                                        $date1 = new DateTime(date('Y-m-d'));
                                                                        $date2 = new DateTime(date('Y-m-d',strtotime($table->share_date)));
                                                                        $diff = $date1->diff($date2);
                                                                    ?>
                                                                    <?php if($diff->days > 30): ?>
                                                                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('prepayment-component',['amortizationschedule'=>$table]);

$__html = app('livewire')->mount($__name, $__params, $table->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                                                    <?php else: ?>
                                                                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('amortization-component',['amortizationschedule'=>$table]);

$__html = app('livewire')->mount($__name, $__params, $table->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                                                    
                                                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                                                    <?php
                                                                        $pad=1;
                                                                    ?>
                                                                <?php endif; ?>
                                                            <?php elseif(count($table->prepayment)): ?>
                                                                <span class="px-1 py-1 rounded text-white" style="background-color:green">Pago Adelantado</span>
                                                                &nbsp;
                                                                <a target="_blank" class="inline-flex items-center justify-center px-4 py-2 bg-red-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-red-500 active:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition ease-in-out duration-150 px-4" href="<?php echo e(route('print-adelanto',$table->prepayment->first()->id)); ?>">
                                                                    <i class="fa-solid fa-print"></i>
                                                                </a>
                                                            <?php elseif($table->total_payment>0): ?>
                                                                <span class="px-1 py-1 rounded text-white" style="background-color:green">Pagado</span>
                                                                &nbsp;
                                                                <a target="_blank" class="inline-flex items-center justify-center px-4 py-2 bg-red-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-red-500 active:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition ease-in-out duration-150 px-4" href="<?php echo e(route('print-recibo',$table->id)); ?>">
                                                                    <i class="fa-solid fa-print"></i>
                                                                </a>
                                                            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                                        </td>
                                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="py-4 mt-3 text-right sm:ml-4 sm:mt-0 sm:text-right">
                <!--[if BLOCK]><![endif]--><?php if($credit->status == 1): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('authorize-credit')): ?>
                        <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['wire:click' => 'authoriz']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'authoriz']); ?>
                            Autorizar
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                <!--[if BLOCK]><![endif]--><?php if($credit->status == 2): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expend-credit')): ?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('credit-expend-component',['credit'=>$credit]);

$__html = app('livewire')->mount($__name, $__params, $credit->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php endif; ?>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d55ee3ed983a76438782c315d95e08b)): ?>
<?php $attributes = $__attributesOriginal7d55ee3ed983a76438782c315d95e08b; ?>
<?php unset($__attributesOriginal7d55ee3ed983a76438782c315d95e08b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d55ee3ed983a76438782c315d95e08b)): ?>
<?php $component = $__componentOriginal7d55ee3ed983a76438782c315d95e08b; ?>
<?php unset($__componentOriginal7d55ee3ed983a76438782c315d95e08b); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\blunkredit\resources\views/livewire/credit-show-component.blade.php ENDPATH**/ ?>