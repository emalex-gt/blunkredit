<div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
    <div class="container justify-center mx-auto">
            <div class="w-full"> 
                <?php echo e($slot); ?>

            </div>
    </div>
</div><?php /**PATH /home3/kodbli/public_html/sistemas/creditos/inveria/resources/views/components/principal.blade.php ENDPATH**/ ?>