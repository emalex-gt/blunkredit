<img src="/build/assets/img/logo.png" style="height:40px" />
<?php /**PATH /home3/kodbli/public_html/sistemas/creditos/inveria/resources/views/components/application-logo.blade.php ENDPATH**/ ?>