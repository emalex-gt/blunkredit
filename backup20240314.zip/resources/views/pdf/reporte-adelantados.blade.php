<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Reporte de Morosos</title>
        <style>
        body{
            font-size:12px;
        }
        h1{
            text-align: center;
            text-transform: uppercase;
            font-size:16px;
        }
        .borde{
            border:1px solid #000;
            padding:20px;
        }
        table{
            width:100%;
            border-spacing: 5px;
            border-collapse: collapse;
        }
        th{
            text-align:center;
            border-bottom:1px solid #000;
        }
        td{
            text-align:right;
        }
    </style>
    </head>
    <body>
        <center><img src="{{asset('build/assets/img/logo.png')}}" height="50px"/></center>
        <h1>INVERIA PRESTAMOS</h1><br><br>
        <h1>REPORTE DE INGRESOS POR APLICAR DEL {{ $desde }} AL {{ $hasta }}</h1>
        <h4 style="text-align:center">Fecha y Hora de Impresión: {{ date('d/m/Y H:i') }}</h4>
        <div>
            <table class="w-full">
            <thead class="bg-gray-200">
                <tr>
                    <th class="px-6 py-2 text-xs text-gray-500">FECHA</th>
                    <th class="px-6 py-2 text-xs text-gray-500">CODIGO</th>
                    <th class="px-6 py-2 text-xs text-gray-500">NOMBRE DEL CLIENTE</th>
                    <th class="px-6 py-2 text-xs text-gray-500">FONDO</th>
                    <th class="px-6 py-2 text-xs text-gray-500">CAPITAL</th>
                    <th class="px-6 py-2 text-xs text-gray-500">INTERES</th>
                    <th class="px-6 py-2 text-xs text-gray-500">MORA</th>
                    <th class="px-6 py-2 text-xs text-gray-500">TOTAL</th>
                    <th class="px-6 py-2 text-xs text-gray-500">ASESOR</th>
                </tr>
            </thead>
            <tbody class="bg-white">
                @if(count($prepayments))
                    @php
                        $total_capital=0;
                        $total_interes=0;
                        $total_delay=0;
                        $total=0;
                    @endphp
                    @foreach ($prepayments as $prepayment)
                        <tr class="border-gray-200 border-b-2" wire:key="customer-{{ $prepayment->id }}">
                            <td class="px-6 py-4 text-md text-gray-500 text-center">{{ date('d/m/Y',strtotime($prepayment->date)) }}</td>
                            <td class="px-6 py-4 text-md text-gray-500 text-center">{{ $prepayment->amortization_schedule->credit->customer->code }}</td>
                            <td class="px-6 py-4 text-md text-gray-500 text-center">{{ $prepayment->amortization_schedule->credit->customer->lastname }}, {{ $prepayment->amortization_schedule->credit->customer->name }}</td>
                            <td class="px-6 py-4 text-md text-gray-500 text-center">{{ $prepayment->amortization_schedule->credit->fund->name }}</td>
                            <td class="px-6 py-4 text-md text-gray-500 text-center">{{ number_format($prepayment->amortization_schedule->capital,2,'.',',') }}</td>
                            <td class="px-6 py-4 text-md text-gray-500 text-center">{{ number_format($prepayment->amortization_schedule->interest,2,'.',',') }}</td>
                            <td class="px-6 py-4 text-md text-gray-500 text-center">{{ number_format($prepayment->amortization_schedule->delay,2,'.',',') }}</td>
                            <td class="px-6 py-4 text-md text-gray-500 text-center">{{ number_format($prepayment->amortization_schedule->total,2,'.',',') }}</td>
                            <td class="px-6 py-4 text-md text-gray-500 text-center">{{ $prepayment->payment_by->name }}</td>
                        </tr>
                        @php
                            $total_capital=$total_capital+$prepayment->amortization_schedule->capital;
                            $total_interes=$total_interes+$prepayment->amortization_schedule->interest;
                            $total_delay=$total_delay+$prepayment->amortization_schedule->delay;
                            $total=$total+$prepayment->amortization_schedule->total;
                        @endphp
                    @endforeach
                        <tr class="border-gray-200 border-b-2">
                            <th class="px-6 py-4 text-md text-gray-500 text-right" colspan="3"></th>
                            <th class="px-6 py-4 text-md text-gray-500 text-right">TOTAL</th>
                            <th class="px-6 py-4 text-md text-gray-500 text-center">{{ number_format($total_capital,2,'.',',') }}</th>
                            <th class="px-6 py-4 text-md text-gray-500 text-center">{{ number_format($total_interes,2,'.',',') }}</th>
                            <th class="px-6 py-4 text-md text-gray-500 text-center">{{ number_format($total_delay,2,'.',',') }}</th>
                            <th class="px-6 py-4 text-md text-gray-500 text-center">{{ number_format($total,2,'.',',') }}</th>
                            <th class="px-6 py-4 text-md text-gray-500 text-center"></th>
                        </tr>
                @else
                    <tr>
                        <td colspan="9" class="px-6 py-4 text-sm text-gray-500 text-center text-lg">
                            No existen registros
                        </td>
                    </tr>
                @endif
            </tbody>
        </table>
        </div>
    </body>
</html>
