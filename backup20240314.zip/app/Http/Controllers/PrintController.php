<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Builder;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Models\Credit;
use App\Models\AmortizationSchedule;
use App\Models\User;
use App\Models\Prepayment;
use App\Models\PartialPayment;
use App\Models\Fund;
use App\Models\FundStatement;
use App\Exports\ExcelExport;
use Maatwebsite\Excel\Facades\Excel;
use DB;

class PrintController extends Controller
{
    //
    public function imprimir_recibo($id){
        $amortization=AmortizationSchedule::find($id);
        return view('pdf.imprimir-recibo',compact('amortization'));
    }
    public function imprimir_adelanto($id){
        $prepayment=Prepayment::find($id);
        return view('pdf.imprimir-adelanto',compact('prepayment'));
    }
    public function imprimir_parcial($id){
        $partialpayment=PartialPayment::find($id);
        return view('pdf.imprimir-parcial',compact('partialpayment'));
    }
    public function reglamodificada($id){
        $credit=Credit::find($id);
        //return view('pdf.regla-modificada',compact('credit'));
        $pdf = Pdf::loadView('pdf.regla-modificada',compact('credit'));
        $pdf->setPaper([0.0, 0.0, 612.00, 936.00], 'portrait');
        return $pdf->download('regla-modificada-'.$id.'.pdf');
    }
    public function reglageneral($id){
        $credit=Credit::find($id);
        //return view('pdf.regla-general',compact('credit'));
        $pdf = Pdf::loadView('pdf.regla-general',compact('credit'));
        $pdf->setPaper([0.0, 0.0, 612.00, 936.00], 'portrait');
        return $pdf->download('regla-general-'.$id.'.pdf');
    }

    public function print_reporte_morosos(){
        /*$amortizations = AmortizationSchedule::where('days_delayed','>',0)
                            ->where('total_payment',0)
                            ->orderBy('id','desc')
                            ->get();
        $users=User::where('id',1)->get();*/
        $users = User::whereHas('credits', function (Builder $query) {
                        $query->whereHas('amortizacion_schedule', function (Builder $query) {
                            $query->where('days_delayed','>',0)
                                    ->where('total_payment',0);
                        });
                    })->get();
        $users_total=User::get();
        //return view('pdf.reporte-morosos',compact('amortizations','users'));
        $pdf = Pdf::loadView('pdf.reporte-morosos',compact('users_total','users'));
        $pdf->setPaper([0.0, 0.0, 612.00, 936.00], 'landscape');
        return $pdf->download('reporte-morosos.pdf');
    }
    public function export_reporte_morosos(){
        /*$amortizations = AmortizationSchedule::where('days_delayed','>',0)
                            ->where('total_payment',0)
                            ->orderBy('id','desc')
                            ->get();
        $users=User::where('id',1)->get();*/
        $users = User::whereHas('credits', function (Builder $query) {
                        $query->whereHas('amortizacion_schedule', function (Builder $query) {
                            $query->where('days_delayed','>',0)
                                    ->where('total_payment',0);
                        });
                    })->get();
        $users_total=User::get();
        $total_total_monto=0;
        $total_total_saldo=0;
        $total_total_capital_atrasado=0;
        $total_total_capital=0;
        $total_total_interes=0;
        $total_total_mora=0;
        $total_total_total=0;

        $total_cartera_monto=0;
        $total_cartera_saldo=0;
        foreach($users as $user){
            $data[] = [
                'Crédito / Dirección',
                'Usuario',
                'Fondo',
                'Monto',
                'Cuota',
                'Saldo Actual',
                'Capital Atrasado',
                'Capital',
                'Interés',
                'Mora',
                'Descuento',
                'Total',
                'Días Atraso',
                'Fecha Venc.',
                'Día Pago'
            ];
            $data[] = [
                ''
            ];
            $data[]= [
                $user->name
            ];
            $data[] = [
                ''
            ];
            $total_monto=0;
            $total_saldo=0;
            $total_capital_atrasado=0;
            $total_capital=0;
            $total_interes=0;
            $total_mora=0;
            $total_total=0;
            foreach($user->credits as $credit){
                foreach($credit->amortizacion_schedule->where('days_delayed','>',0) as $amortization){
                    $data[] = [
                        $amortization->credit->code.' '.$amortization->credit->customer->name.' '.$amortization->credit->customer->lastname.' / '.$amortization->credit->customer->address.' '.$amortization->credit->customer->phone,
                        $amortization->credit->created_by->name,
                        $amortization->credit->fund->name,
                        number_format($amortization->credit->initial_credit_capital,2,'.',','),
                        number_format(($amortization->total),2,'.',','),
                        number_format($amortization->credit->pending_credit_capital,2,'.',','),
                        number_format($amortization->capital,2,'.',','),
                        number_format($amortization->capital,2,'.',','),
                        number_format($amortization->interest,2,'.',','),
                        number_format($amortization->delay,2,'.',','),
                        '0.00',
                        number_format(($amortization->total + $amortization->delay),2,'.',','),
                        $amortization->days_delayed,
                        date('d/m/Y',strtotime($amortization->share_date)),
                        date('d',strtotime($amortization->share_date))
                    ];
                    $total_monto=$total_monto+$amortization->credit->initial_credit_capital;
                    $total_saldo=$total_saldo+$amortization->credit->pending_credit_capital;
                    $total_capital_atrasado=$total_capital_atrasado+$amortization->capital;
                    $total_capital=$total_capital+$amortization->capital;
                    $total_interes=$total_interes+$amortization->interest;
                    $total_mora=$total_mora+$amortization->delay;
                    $total_total=$total_total+($amortization->total + $amortization->delay);
                }
            }
            $total_total_monto=$total_total_monto+$total_monto;
            $total_total_saldo=$total_total_saldo+$total_saldo;
            $total_total_capital_atrasado=$total_total_capital_atrasado+$total_capital_atrasado;
            $total_total_capital=$total_total_capital+$total_capital;
            $total_total_interes=$total_total_interes+$total_interes;
            $total_total_mora=$total_total_mora+$total_mora;
            $total_total_total=$total_total_total+$total_total;
            $data[] = [
                '',
                '',
                'Total por Asesor',
                number_format($total_monto,2,'.',','),
                '',
                number_format($total_saldo,2,'.',','),
                number_format($total_capital_atrasado,2,'.',','),
                number_format($total_capital,2,'.',','),
                number_format($total_interes,2,'.',','),
                number_format($total_mora,2,'.',','),
                '',
                number_format(($total_total),2,'.',','),
                '',
                '',
                ''
            ];
            $cartera_monto=0;
            $cartera_saldo=0;
            foreach($user->credits as $credit){
                $cartera_monto=$cartera_monto+$credit->initial_credit_capital;
                $cartera_saldo=$cartera_saldo+$credit->pending_credit_capital;
            }
            $data[] = [
                '',
                '',
                'Cartera Total',
                number_format($cartera_monto,2,'.',','),
                '',
                number_format($cartera_saldo,2,'.',','),
                '',
                '',
                '',
                '',
                '',
                '',
                ''
            ];
            $data[] = [
                ''
            ];
            $data[] = [
                ''
            ];
            $data[] = [
                'Coeficientes de la Cartera'
            ];
            $data[] = [
                'Monto Entregado',
                $cartera_monto,
                '100%',
            ];
            $data[] = [
                'Cartera Pagada',
                number_format(($cartera_monto - $cartera_saldo),2,'.',','),
                number_format(((($cartera_monto-$cartera_saldo)/$cartera_monto)*100),2,'.',',').'%'
            ];
            $data[] = [
                'Cartera Mora',
                number_format($total_capital_atrasado,2,'.',','),
                number_format((($total_capital_atrasado/$cartera_monto)*100),2,'.',',').'%'
            ];
            $data[] = [
                'Capital en Riesgo',
                number_format($total_saldo,2,'.',','),
                number_format((($total_saldo/$cartera_monto)*100),2,'.',',').'%'
            ];
            $data[] = [
                'Saldo de la Cartera',
                number_format($cartera_saldo,2,'.',','),
                number_format((($cartera_saldo/$cartera_monto)*100),2,'.',',').'%'
            ];
            $data[] = [
                ''
            ];
            $data[] = [
                ''
            ];
        }
        foreach($users_total as $us){
            foreach($us->credits as $cred){
                $total_cartera_monto=$total_cartera_monto+$cred->initial_credit_capital;
                $total_cartera_saldo=$total_cartera_saldo+$cred->pending_credit_capital;
            }
        }
        $data[]=[
            '',
            'Monto / Cuota',
            'Saldo Actual',
            'Capital Atrasado',
            'Capital',
            'Interés',
            'Mora / Descuento'
        ];
        $data[]=[
            'Total General',
            number_format($total_total_monto,2,'.',','),
            number_format($total_total_saldo,2,'.',','),
            number_format($total_total_capital_atrasado,2,'.',','),
            number_format($total_total_capital,2,'.',','),
            number_format($total_total_interes,2,'.',','),
            number_format($total_total_mora,2,'.',','),
        ];
        $data[]=[
            'Cartera Total',
            number_format($total_cartera_monto,2,'.',','),
            number_format($total_cartera_saldo,2,'.',','),
            '',
            '',
            '',
            '',
        ];
        $data[] = [
            ''
        ];
        $data[] = [
            ''
        ];
        $data[] = [
            'Coeficientes de la Cartera'
        ];
        $data[] = [
            'Monto Entregado',
            $total_cartera_monto,
            '100%',
        ];
        $data[] = [
            'Cartera Pagada',
            number_format(($total_cartera_monto - $total_cartera_saldo),2,'.',','),
            number_format(((($total_cartera_monto-$total_cartera_saldo)/$total_cartera_monto)*100),2,'.',',').'%'
        ];
        $data[] = [
            'Cartera Mora',
            number_format($total_total_capital_atrasado,2,'.',','),
            number_format((($total_total_capital_atrasado/$total_cartera_monto)*100),2,'.',',').'%'
        ];
        $data[] = [
            'Capital en Riesgo',
            number_format($total_total_saldo,2,'.',','),
            number_format((($total_total_saldo/$total_cartera_monto)*100),2,'.',',').'%'
        ];
        $data[] = [
            'Saldo de la Cartera',
            number_format($total_cartera_saldo,2,'.',','),
            number_format((($total_cartera_saldo/$total_cartera_monto)*100),2,'.',',').'%'
        ];
        $data[] = [
            ''
        ];
        $data[] = [
            ''
        ];
        //return view('pdf.reporte-morosos',compact('amortizations','users'));
        $export = new ExcelExport($data);
        return Excel::download($export,'reporte-morosos.xlsx');
    }

    public function print_reporte_proyeccion($desde,$hasta){
        $amortizations = DB::table('amortization_schedules as a')
                            ->select('a.id','a.share_date','c.code','c.created_user','cl.lastname','cl.name','cl.address','cl.phone','u.name as user','a.capital','a.interest','a.total','a.delay','f.name as fund')
                            ->join('credits as c','c.id','=','a.credit_id')
                            ->join('funds as f','f.id','=','c.fund_id')
                            ->join('users as u','u.id','=','c.created_user')
                            ->join('customers as cl','cl.id','=','c.customer_id')
                            ->where('a.total_payment',0)
                            ->where(function($query) use($desde, $hasta)
                            {
                                $query->where(function($query) use($desde, $hasta)
                                {
                                    $query->whereBetween('a.share_date',[$desde.' 00:00:00',$hasta.' 23:59:59'])
                                    ->where('a.delay',0);

                                })
                                ->orWhere('a.delay','>',0);
                            })
                            ->orderBy('c.created_user','asc')
                            ->orderBy('a.share_date','asc')
                            ->get();
        //return view('pdf.reporte-proyeccion',compact('amortizations','desde','hasta'));
        $pdf = Pdf::loadView('pdf.reporte-proyeccion',compact('amortizations','desde','hasta'));
        $pdf->setPaper([0.0, 0.0, 612.00, 936.00], 'landscape');
        return $pdf->download('reporte-proyeccion.pdf');
    }
    public function export_reporte_proyeccion($desde,$hasta){
        $amortizations = DB::table('amortization_schedules as a')
                            ->select('a.id','a.share_date','c.code','c.created_user','cl.lastname','cl.name','cl.address','cl.phone','u.name as user','a.capital','a.interest','a.total','a.delay','f.name as fund')
                            ->join('credits as c','c.id','=','a.credit_id')
                            ->join('funds as f','f.id','=','c.fund_id')
                            ->join('users as u','u.id','=','c.created_user')
                            ->join('customers as cl','cl.id','=','c.customer_id')
                            ->where('a.total_payment',0)
                            ->where(function($query) use($desde, $hasta)
                            {
                                $query->where(function($query) use($desde, $hasta)
                                {
                                    $query->whereBetween('a.share_date',[$desde.' 00:00:00',$hasta.' 23:59:59'])
                                    ->where('a.delay',0);

                                })
                                ->orWhere('a.delay','>',0);
                            })
                            ->orderBy('c.created_user','asc')
                            ->orderBy('a.share_date','asc')
                            ->get();
        $data[]=[
            'Crédito',
            'Nombre Completo',
            'Dirección',
            'Fondo',
            'Teléfono',
            'Capital',
            'Interés',
            'Mora',
            'Total'
        ];
        $total_capital=0;
        $total_interes=0;
        $total_delay=0;
        $total=0;

        $total_day_capital=0;
        $total_day_interes=0;
        $total_day_delay=0;
        $total_day=0;

        $dia='';
        $asesor='';
        foreach ($amortizations as $amortization){
            if($asesor!=$amortization->created_user){
                $data[]=[
                    $amortization->user
                ];
                $asesor=$amortization->created_user;
            }
            if($dia!='' && $dia!=date('Y-m-d',strtotime($amortization->share_date))){
                $data[]=[
                    '',
                    '',
                    '',
                    'Total del día '.date('d/m/Y',strtotime($dia)),
                    '',
                    number_format($total_day_capital,2,'.',','),
                    number_format($total_day_interes,2,'.',','),
                    number_format($total_day_delay,2,'.',','),
                    number_format($total_day,2,'.',',')
                ];
                $data[]=[
                    ''
                ];
                $total_day_capital=0;
                $total_day_interes=0;
                $total_day_delay=0;
                $total_day=0;
            }
            $data[]=[
                $amortization->code,
                $amortization->lastname.', '.$amortization->name,
                $amortization->address,
                $amortization->fund,
                $amortization->phone,
                number_format($amortization->capital,2,'.',','),
                number_format($amortization->interest,2,'.',','),
                number_format($amortization->delay,2,'.',','),
                number_format(($amortization->total+$amortization->delay),2,'.',','),
            ];
            $dia=date('Y-m-d',strtotime($amortization->share_date));
            $total_capital=$total_capital+$amortization->capital;
            $total_interes=$total_interes+$amortization->interest;
            $total_delay=$total_delay+$amortization->delay;
            $total=$total+($amortization->total+$amortization->delay);

            $total_day_capital=$total_day_capital+$amortization->capital;
            $total_day_interes=$total_day_interes+$amortization->interest;
            $total_day_delay=$total_day_delay+$amortization->delay;
            $total_day=$total_day+($amortization->total+$amortization->delay);
        }
        $data[]=[
            '',
            '',
            '',
            'Total del día '.date('d/m/Y',strtotime($dia)),
            '',
            number_format($total_day_capital,2,'.',','),
            number_format($total_day_interes,2,'.',','),
            number_format($total_day_delay,2,'.',','),
            number_format($total_day,2,'.',',')
        ];
        $data[]=[
            ''
        ];
        $data[]=[
            '',
            '',
            '',
            'Total por periodo',
            '',
            number_format($total_capital,2,'.',','),
            number_format($total_interes,2,'.',','),
            number_format($total_delay,2,'.',','),
            number_format($total,2,'.',',')
        ];
        $export = new ExcelExport($data);
        return Excel::download($export,'reporte-proyeccion.xlsx');
    }

    public function print_reporte_recuperacion($asesor,$desde,$hasta){
        if($asesor==0)
            $comparador='>';
        else
            $comparador='=';
        $amortizations = AmortizationSchedule::where('total_payment','>',0)
                            ->whereHas('payment_by', function (Builder $query) use($comparador,$asesor) {
                                $query->where('id', $comparador, $asesor);
                            })
                            ->whereBetween('payment_date',[$desde.' 00:00:00',$hasta.' 23:59:59'])
                            ->orderBy('id','desc')
                            ->get();
        $pdf = Pdf::loadView('pdf.reporte-recuperacion',compact('amortizations','desde','hasta'));
        $pdf->setPaper([0.0, 0.0, 612.00, 936.00], 'landscape');
        return $pdf->download('reporte-recuperacion.pdf');
    }
    public function export_reporte_recuperacion($asesor,$desde,$hasta){
        if($asesor==0)
            $comparador='>';
        else
            $comparador='=';
        $amortizations = AmortizationSchedule::where('total_payment','>',0)
                            ->whereHas('payment_by', function (Builder $query) use($comparador,$asesor) {
                                $query->where('id', $comparador, $asesor);
                            })
                            ->whereBetween('payment_date',[$desde.' 00:00:00',$hasta.' 23:59:59'])
                            ->orderBy('id','desc')
                            ->get();
        //Creando Excel
        $i = 0;
        //print_r($amortizations);
        $data[] = [
            'FECHA',
            'CODIGO',
            'NOMBRE DEL CLIENTE',
            'FONDO',
            'CAPITAL',
            'INTERES',
            'MORA',
            'TOTAL',
            'ASESOR'
        ];
        foreach ($amortizations as $amortization){
            $data[] = [
                date('d/m/Y',strtotime($amortization->payment_date)),
                $amortization->credit->customer->code,
                $amortization->credit->customer->lastname.', '.$amortization->credit->customer->name,
                $amortization->credit->fund->name,
                number_format($amortization->capital,2,'.',''),
                number_format($amortization->interest,2,'.',''),
                number_format($amortization->delay,2,'.',''),
                number_format($amortization->total_payment,2,'.',''),
                $amortization->payment_by->name
            ];
            $i++;
        }
        if ($i==0) {
            $data[] = ['Sin Registros' => ''];
        }
        //print_r($data);
        //die();
        $export = new ExcelExport($data);
        return Excel::download($export,'reporte-recuperacion.xlsx');
    }

    public function print_reporte_adelantados($asesor,$desde,$hasta){
        if($asesor==0)
            $comparador='>';
        else
            $comparador='=';
        $prepayments = Prepayment::where('status',1)
                            ->whereHas('payment_by', function (Builder $query) use($comparador,$asesor) {
                                $query->where('id', $comparador, $asesor);
                            })
                            ->whereBetween('date',[$desde.' 00:00:00',$hasta.' 23:59:59'])
                            ->orderBy('id','desc')
                            ->get();
        
        $pdf = Pdf::loadView('pdf.reporte-adelantados',compact('prepayments','desde','hasta'));
        $pdf->setPaper([0.0, 0.0, 612.00, 936.00], 'landscape');
        return $pdf->download('reporte-adelantados.pdf');
    }
    public function export_reporte_adelantados($asesor,$desde,$hasta){
        if($asesor==0)
            $comparador='>';
        else
            $comparador='=';
        $prepayments = Prepayment::where('status',1)
                            ->whereHas('payment_by', function (Builder $query) use($comparador,$asesor) {
                                $query->where('id', $comparador, $asesor);
                            })
                            ->whereBetween('date',[$desde.' 00:00:00',$hasta.' 23:59:59'])
                            ->orderBy('id','desc')
                            ->get();
        //Creando Excel
        $i = 0;
        //print_r($amortizations);
        $data[] = [
            'FECHA',
            'CODIGO',
            'NOMBRE DEL CLIENTE',
            'FONDO',
            'CAPITAL',
            'INTERES',
            'MORA',
            'TOTAL',
            'ASESOR'
        ];
        foreach ($prepayments as $prepayment){
            $data[] = [
                date('d/m/Y',strtotime($prepayment->date)),
                $prepayment->amortization_schedule->credit->customer->code,
                $prepayment->amortization_schedule->credit->customer->lastname.', '.$prepayment->amortization_schedule->credit->customer->name,
                $prepayment->amortization_schedule->credit->fund->name,
                number_format($prepayment->amortization_schedule->capital,2,'.',''),
                number_format($prepayment->amortization_schedule->interest,2,'.',''),
                number_format($prepayment->amortization_schedule->delay,2,'.',''),
                number_format($prepayment->amortization_schedule->total,2,'.',''),
                $prepayment->payment_by->name
            ];
            $i++;
        }
        if ($i==0) {
            $data[] = ['Sin Registros' => ''];
        }
        //print_r($data);
        //die();
        $export = new ExcelExport($data);
        return Excel::download($export,'reporte-adelantados.xlsx');
    }

    public function print_reporte_colocacion($asesor,$desde,$hasta){
        if($asesor==0)
            $comparador='>';
        else
            $comparador='=';
        $credits = Credit::where('status','>',2)
                            ->whereHas('expended_by', function (Builder $query) use($comparador,$asesor) {
                                $query->where('id', $comparador, $asesor);
                            })
                            ->whereBetween('expended_at',[$desde.' 00:00:00',$hasta.' 23:59:59'])
                            ->orderBy('id','desc')
                            ->get();
        $pdf = Pdf::loadView('pdf.reporte-colocacion',compact('credits','desde','hasta'));
        $pdf->setPaper([0.0, 0.0, 612.00, 936.00], 'landscape');
        return $pdf->download('reporte-colocacion.pdf');
    }
    public function export_reporte_colocacion($asesor,$desde,$hasta){
        if($asesor==0)
            $comparador='>';
        else
            $comparador='=';
        $credits = Credit::where('status','>',2)
                            ->whereHas('expended_by', function (Builder $query) use($comparador,$asesor) {
                                $query->where('id', $comparador, $asesor);
                            })
                            ->whereBetween('expended_at',[$desde.' 00:00:00',$hasta.' 23:59:59'])
                            ->orderBy('id','desc')
                            ->get();
        //Creando Excel
        $i = 0;
        //print_r($amortizations);
        $data[] = [
            'CODIGO DEL CREDITO',
            'NOMBRE DEL CLIENTE',
            'TIPO',
            'CAPITAL',
            'FECHA DESEMBOLSO'
        ];
        foreach ($credits as $credit){
            $data[] = [
                $credit->code,
                $credit->customer->lastname.', '.$credit->customer->name,
                'NUEVO',
                number_format($credit->initial_credit_capital,2,'.',''),
                date('d/m/Y',strtotime($credit->expended_at)),
            ];
            $i++;
        }
        if ($i==0) {
            $data[] = ['Sin Registros' => ''];
        }
        //print_r($data);
        //die();
        $export = new ExcelExport($data);
        return Excel::download($export,'reporte-colocacion.xlsx');
    }

    public function print_statement($id){
        $statements = FundStatement::where('fund_id',$id)
                                ->orderBy('id','desc')
                                ->get();
        $fund = Fund::find($id);
        $pdf = Pdf::loadView('pdf.reporte-fondo',compact('statements','fund'));
        $pdf->setPaper([0.0, 0.0, 612.00, 936.00], 'landscape');
        return $pdf->download('reporte-fondo.pdf');
    }
    public function export_statement($id){
        $statements = FundStatement::where('fund_id',$id)
                                ->orderBy('id','desc')
                                ->get();
        //Creando Excel
        $i = 0;
        //print_r($amortizations);
        $data[] = [
            'FECHA',
            'TIPO',
            'CRÉDITO',
            'DÉBITO',
            'SALDO'
        ];
        foreach ($statements as $statement){
            switch ($statement->type) {
                case 1:
                    $type='Apertura de Fondo';
                    break;
                case 2:
                    $type='Suma de Capital de Inversor/Dueño';
                    break;
                case 3:
                    $type='Suma de Capital de Fondo';
                    break;
                case 4:
                    $type='Desembolso de Crédito';
                    break;
                case 5:
                    $type='Abono de Crédito';
                    break;
                case 6:
                    $type='Retiro de Capital de Fondo';
                    break;
                default:
                    $type='Otros'; 
            }
            $data[] = [
                date('Y-m-d H:i',strtotime($statement->date)),
                $type,
                number_format($statement->credit,2,'.',','),
                number_format($statement->debit,2,'.',','),
                number_format($statement->balance,2,'.',',')
            ];
            $i++;
        }
        if ($i==0) {
            $data[] = ['Sin Registros' => ''];
        }
        //print_r($data);
        //die();
        $export = new ExcelExport($data);
        return Excel::download($export,'reporte-fondo.xlsx');
    }
}
