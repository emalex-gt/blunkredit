<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\AmortizationSchedule;
use App\Models\Credit;
use App\Models\FundStatement;
use App\Models\FundStatementDetail;
use Auth;

class AmortizationComponent extends Component
{
    public $open=false;
    public $amortizationschedule;

    protected $rules = [
        'amortizationschedule.receipt_number' => 'required'
    ];

    public function mount(AmortizationSchedule $amortizationschedule){
        $this->amortizationschedule=$amortizationschedule;
    }

    public function render()
    {
        return view('livewire.amortization-component');
    }
    
    public function save(){
        $this->validate();

        $user = Auth::user();
        $credit = Credit::find($this->amortizationschedule->credit_id);
        
        //Save Amortization
        $this->amortizationschedule->payment_date=date('Y-m-d H:i:s');
        $this->amortizationschedule->total_payment=($this->amortizationschedule->capital + $this->amortizationschedule->interest + $this->amortizationschedule->delay);
        $this->amortizationschedule->capital_balance_payment=$credit->amortized_credit_capital + $this->amortizationschedule->capital;
        $this->amortizationschedule->interest_balance_payment=$credit->interest_paid + $this->amortizationschedule->interest;
        $this->amortizationschedule->total_balance_payment=$credit->total_paid + $this->amortizationschedule->total_payment;
        $this->amortizationschedule->payment_user=$user->id;
        $this->amortizationschedule->payment_at=date('Y-m-d H:i:s');
        $this->amortizationschedule->save();

        //Update Credit
        $credit->amortized_credit_capital= $credit->amortized_credit_capital + $this->amortizationschedule->capital;
        $credit->pending_credit_capital= $credit->pending_credit_capital - $this->amortizationschedule->capital;
        $credit->interest_paid= $credit->interest_paid + $this->amortizationschedule->interest;
        $credit->delay_paid= $credit->delay_paid + $this->amortizationschedule->delay;
        $credit->total_paid= $credit->total_paid + $this->amortizationschedule->total_payment;
        $credit->save();

        foreach($this->amortizationschedule->credit->partial_payments()->where('amortization_schedule_id',0)->get() as $prepayment){
            $prepayment->amortization_schedule_id = $this->amortizationschedule->id;
            $prepayment->save();

            //Statement
            $last_statement=FundStatement::where('fund_id',4)->orderBy('id','desc')->first();
            if($last_statement===NULL){
                $bal=0;
            } else {
                $bal=$last_statement->balance;
            }
            
            $fund_statament=FundStatement::create([
                'fund_id' => 4,
                'date' => date('Y-m-d H:i:s'),
                'type' => 6,
                'credit' => 0,
                'debit' => $prepayment->amount,
                'balance' => $bal - $prepayment->amount,
                'create_user' => $user->id
            ]);
            FundStatementDetail::create([
                'fund_statement_id' => $fund_statament->id,
                'credit_code' => 0,
                'info' => 'Retiro de Pago Parcial a Abono #'.$this->amortizationschedule->id.' en Crédito '.$this->amortizationschedule->credit->code,
                'receipt_number' => $prepayment->receipt_number,
                'amount' => $prepayment->amount
            ]);
        }

        //Statement Capital
        $last_statement=FundStatement::where('fund_id',$credit->fund_id)->orderBy('id','desc')->first();
        if($last_statement===NULL){
            $bal=0;
        } else {
            $bal=$last_statement->balance;
        }
                
        $fund_statament=FundStatement::create([
            'fund_id' => $credit->fund_id,
            'date' => date('Y-m-d H:i:s'),
            'type' => 5,
            'credit' => $this->amortizationschedule->capital,
            'debit' => 0,
            'balance' => $bal + $this->amortizationschedule->capital,
            'create_user' => $user->id
        ]);
        FundStatementDetail::create([
            'fund_statement_id' => $fund_statament->id,
            'credit_code' => $credit->id,
            'info' => 'Abono de Capital a Crédito '.$credit->code,
            'receipt_number' => $this->amortizationschedule->receipt_number,
            'amount' => $this->amortizationschedule->capital
        ]);

        //Statement Interes
        $last_statement=FundStatement::where('fund_id',1)->orderBy('id','desc')->first();
        if($last_statement===NULL){
            $bal=0;
        } else {
            $bal=$last_statement->balance;
        }
                
        $fund_statament=FundStatement::create([
            'fund_id' => 1,
            'date' => date('Y-m-d H:i:s'),
            'type' => 5,
            'credit' => $this->amortizationschedule->interest,
            'debit' => 0,
            'balance' => $bal + $this->amortizationschedule->interest,
            'create_user' => $user->id
        ]);
        FundStatementDetail::create([
            'fund_statement_id' => $fund_statament->id,
            'credit_code' => $credit->id,
            'info' => 'Abono de Interés a Crédito '.$credit->code,
            'receipt_number' => $this->amortizationschedule->receipt_number,
            'amount' => $this->amortizationschedule->interest
        ]);

        //Statement Mora
        if($this->amortizationschedule->delay > 0){
            $last_statement=FundStatement::where('fund_id',1)->orderBy('id','desc')->first();
            if($last_statement===NULL){
                $bal=0;
            } else {
                $bal=$last_statement->balance;
            }
                    
            $fund_statament=FundStatement::create([
                'fund_id' => 1,
                'date' => date('Y-m-d H:i:s'),
                'type' => 5,
                'credit' => $this->amortizationschedule->delay,
                'debit' => 0,
                'balance' => $bal + $this->amortizationschedule->delay,
                'create_user' => $user->id
            ]);
            FundStatementDetail::create([
                'fund_statement_id' => $fund_statament->id,
                'credit_code' => $credit->id,
                'info' => 'Abono de Mora a Crédito '.$credit->code,
                'receipt_number' => $this->amortizationschedule->receipt_number,
                'amount' => $this->amortizationschedule->delay
            ]);
        }

        $this->reset('open');
        $this->dispatch('ok');
        $this->dispatch('redirect');
    }
}
