<?php

namespace App\Livewire;

use Livewire\Component;
use Illuminate\Database\Eloquent\Builder;
use App\Models\Credit;
use DB;

class CreditListComponent extends Component
{
    public $search='';
    public $status;
    public $comparador='=';

    public function mount(){
        $this->status=0;
    }

    public function render()
    {
        if($this->status==0)
            $this->comparador='>';
        else
            $this->comparador='=';
        $credits = Credit::where(function ($query) {
                                    $query->whereHas('customer', function (Builder $query) {
                                        $query->where(DB::raw('CONCAT(name,dpi,email,code)'),'like','%'.$this->search.'%');
                                    });
                                })
                                ->where('status',$this->comparador,$this->status)
                                ->orderBy('id','desc')
                                ->paginate(30);
        return view('livewire.credit-list-component',compact('credits'));
    }
}
