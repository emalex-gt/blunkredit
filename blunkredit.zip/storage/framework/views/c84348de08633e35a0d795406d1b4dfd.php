<div>
    
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Listado de Créditos')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <?php if (isset($component)) { $__componentOriginal7d55ee3ed983a76438782c315d95e08b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d55ee3ed983a76438782c315d95e08b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.principal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('principal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="px-6 py-4 text-right">
            Estado:
            <select wire:model.live="status">
                <option value="0">Todos</option>
                <option value="1">Registrado</option>
                <option value="2">Autorizado</option>
                <option value="3">Activo</option>
                <option value="4">Finalizado</option>
            </select>
            <?php if (isset($component)) { $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['class' => 'w-1/2','placeholder' => '&#xF002; Buscar por Cliente','type' => 'text','wire:model.live' => 'search','style' => 'font-family:Arial, FontAwesome']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-1/2','placeholder' => '&#xF002; Buscar por Cliente','type' => 'text','wire:model.live' => 'search','style' => 'font-family:Arial, FontAwesome']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $attributes = $__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__attributesOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1)): ?>
<?php $component = $__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1; ?>
<?php unset($__componentOriginalc2fcfa88dc54fee60e0757a7e0572df1); ?>
<?php endif; ?>
        </div>
        <table class="w-full">
            <thead class="bg-gray-200">
                <tr class="border-gray-200 border-b-2">
                    <th class="px-6 py-2 text-xs text-gray-500">CODIGO</th>
                    <th class="px-6 py-2 text-xs text-gray-500">FONDO</th>
                    <th class="px-6 py-2 text-xs text-gray-500">TECNOLOGÍA</th>
                    <th class="px-6 py-2 text-xs text-gray-500">GARANTÍA</th>
                    <th class="px-6 py-2 text-xs text-gray-500">CAPITAL INICIAL</th>
                    <th class="px-6 py-2 text-xs text-gray-500">CAPITAL PENDIENTE</th>
                    <th class="px-6 py-2 text-xs text-gray-500">ESTADO</th>
                    <th class="px-6 py-2 text-xs text-gray-500"></th>
                </tr>
            </thead>
            <tbody class="bg-white">
                <!--[if BLOCK]><![endif]--><?php if(count($credits)): ?>                
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $credits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-gray-200 border-b-2">
                            <td class="px-6 py-4 text-md text-gray-500 text-center"><?php echo e($credit->code); ?></td>
                            <td class="px-6 py-4 text-md text-gray-500 text-center"><?php echo e($credit->fund->name); ?></td>
                            <td class="px-6 py-4 text-md text-gray-500 text-center"><?php echo e($credit->tecnology->name); ?></td>
                            <td class="px-6 py-4 text-md text-gray-500 text-center"><?php echo e($credit->guarantee->name); ?></td>
                            <td class="px-6 py-4 text-md text-gray-500 text-center">Q.<?php echo e(number_format($credit->initial_credit_capital,2,'.',',')); ?></td>
                            <td class="px-6 py-4 text-md text-gray-500 text-center">Q.<?php echo e(number_format($credit->pending_credit_capital,2,'.',',')); ?></td>
                            <td class="px-6 py-4 text-md text-gray-500 text-center">
                                <!--[if BLOCK]><![endif]--><?php switch($credit->status):
                                    case (1): ?>
                                        <span class="px-1 py-1 rounded" style="background-color:yellow">Registrado</span>
                                        <?php break; ?>
                                    <?php case (2): ?>
                                        <span class="px-1 py-1 rounded text-white" style="background-color:orange">Autorizado</span>
                                        <?php break; ?>
                                    <?php case (3): ?>
                                        <span class="px-1 py-1 rounded text-white" style="background-color:green">Activo</span>
                                        <?php break; ?>
                                    <?php case (4): ?>
                                        <span class="px-1 py-1 rounded text-white" style="background-color:red">Finalizado</span>
                                        <?php break; ?>
                                <?php endswitch; ?> <!--[if ENDBLOCK]><![endif]-->
                            </td>
                            <td class="px-6 py-4 text-md text-gray-500 text-center">
                                <a href="<?php echo e(route('credito',$credit->id)); ?>" class="inline-block px-1 py-1 bg-gray-800 border border-transparent rounded-md text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition">
                                    <small><i class="fa-solid fa-eye"></i></small>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="px-6 py-4 text-sm text-gray-500 text-center text-lg">
                            No existen registros
                        </td>
                    </tr>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>

        <!--[if BLOCK]><![endif]--><?php if(count($credits)): ?>
            <!--[if BLOCK]><![endif]--><?php if($credits->hasPages()): ?>
                <div class="px-6 py-3">
                    <?php echo e($credits->links()); ?>

                </div>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d55ee3ed983a76438782c315d95e08b)): ?>
<?php $attributes = $__attributesOriginal7d55ee3ed983a76438782c315d95e08b; ?>
<?php unset($__attributesOriginal7d55ee3ed983a76438782c315d95e08b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d55ee3ed983a76438782c315d95e08b)): ?>
<?php $component = $__componentOriginal7d55ee3ed983a76438782c315d95e08b; ?>
<?php unset($__componentOriginal7d55ee3ed983a76438782c315d95e08b); ?>
<?php endif; ?>
    <?php $__env->startPush('js'); ?>
        <script>
            $( ".button-toggle" ).on( "click", function() {
                var refid = $(this).attr('ref-id');
                $( "#show-" + refid ).toggle( "slow" );
            });
        </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\blunkredit\resources\views/livewire/credit-list-component.blade.php ENDPATH**/ ?>