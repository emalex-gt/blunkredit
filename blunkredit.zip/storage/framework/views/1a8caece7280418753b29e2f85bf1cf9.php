<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Datos de Crédito - Regla General</title>
        <style>
        body{
            font-size:12px;
        }
        h1{
            text-align: center;
            text-transform: uppercase;
            font-size:16px;
        }
        .borde{
            border:1px solid #000;
            padding:20px;
        }
        table{
            width:100%;
            border-spacing: 5px;
            border-collapse: collapse;
        }
        th{
            text-align:center;
            border-bottom:1px solid #000;
        }
        td{
            text-align:right;
        }
    </style>
    </head>
    <body onload="window.print()">
        <center><img src="<?php echo e(asset('build/assets/img/logo.png')); ?>" height="50px"/></center>
        <h1>INVERIA PRESTAMOS</h1>
        <h4>Fecha y Hora de Impresión: <?php echo e(date('d/m/Y H:i')); ?></h4>
        <div class="borde">
            <h1>DATOS GENERAL DEL CRÉDITO</h1>
            <table>
                <tr>
                    <td style="text-align:left">Nombre del Usuario:</td>
                    <td style="text-align:left" colspan="3"><?php echo e($credit->customer->name); ?> <?php echo e($credit->customer->lastname); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Grupo/Banco:</td>
                    <td style="text-align:left" colspan="3"><?php echo e($credit->tecnology->name); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Dirección:</td>
                    <td style="text-align:left" colspan="3"><?php echo e($credit->customer->address); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Nombre Fondo:</td>
                    <td style="text-align:left"><?php echo e($credit->fund->name); ?></td>
                    <td style="text-align:left">NIT:</td>
                    <td style="text-align:left"></td>
                </tr>
                <tr>
                    <td style="text-align:left">Código de Usuario:</td>
                    <td style="text-align:left"><?php echo e($credit->customer->code); ?></td>
                    <td style="text-align:left">Número de Crédito:</td>
                    <td style="text-align:left"><?php echo e($credit->code); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Fecha de Entrega:</td>
                    <td style="text-align:left"><?php echo e(date('d/m/Y',strtotime($credit->expended_at))); ?></td>
                    <td style="text-align:left">Fecha de Vencim.:</td>
                    <td style="text-align:left"><?php echo e(date('d/m/Y',strtotime($credit->amortizacion_schedule->sortDesc()->first()->share_date))); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Plazo en Meses:</td>
                    <td style="text-align:left"><?php echo e($credit->time_limit->name); ?></td>
                    <td style="text-align:left">Capital:</td>
                    <td style="text-align:left"><?php echo e(number_format($credit->initial_credit_capital,2,'.',',')); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Tasa de Interés:</td>
                    <td style="text-align:left"><?php echo e($credit->interest->name); ?>%</td>
                    <td style="text-align:left">Política:</td>
                    <td style="text-align:left"><?php echo e($credit->policy->name); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Cédula/DPI:</td>
                    <td style="text-align:left"><?php echo e($credit->customer->dpi); ?></td>
                    <td style="text-align:left">Usuario Operó</td>
                    <td style="text-align:left"><?php echo e($credit->created_by->id); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Asesor:</td>
                    <td style="text-align:left"><?php echo e($credit->created_by->name); ?></td>
                    <td style="text-align:left"></td>
                    <td style="text-align:left"></td>
                </tr>
                <tr>
                    <td style="text-align:left">Garantía:</td>
                    <td style="text-align:left"><?php echo e($credit->guarantee->name); ?></td>
                    <td style="text-align:left">Primer Pago:</td>
                    <td style="text-align:left"><?php echo e(date('d/m/Y',strtotime($credit->amortizacion_schedule->sort()->first()->share_date))); ?></td>
                </tr>
                <tr>
                    <td style="text-align:left">Línea de Crédito:</td>
                    <td style="text-align:left"><?php echo e($credit->credit_line->name); ?></td>
                    <td style="text-align:left">Cuota:</td>
                    <td style="text-align:left"><?php echo e(number_format($credit->amortizacion_schedule->sort()->first()->capital,2,'.',',')); ?></td>
                </tr>
            </table>
        </div>
        <h1>REGLA DE PAGO ORIGINAL</h1>
        <center>
            <table style="width:75%">
                <tr>
                    <th style="border:1px solid #000">Fecha Prevista<br>de Pago</th>
                    <th style="border:1px solid #000">Días</th>
                    <th style="border:1px solid #000">Cuota<br>Capital</th>
                    <th style="border:1px solid #000">Cuota<br>Interés</th>
                    <th style="border:1px solid #000">Cuota<br>Total</th>
                    <th style="border:1px solid #000">Deuda<br>Residual</th>
                </tr>
                <?php
                    $fecha_anterior=$credit->expended_at;
                    $tot_dias=0;
                    $tot_capital=0;
                    $tot_interes=0;
                    $tot_total=0;
                ?>
                <?php $__currentLoopData = $credit->amortizacion_schedule->where('total_payment',0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="text-align:center"><?php echo e(date('d/m/Y',strtotime($table->share_date))); ?></td>
                        <td style="text-align:center">
                            <?php
                                $date1 = new DateTime(date('Y-m-d',strtotime($fecha_anterior)));
                                $date2 = new DateTime(date('Y-m-d',strtotime($table->share_date)));
                                $diff = $date1->diff($date2);
                                $fecha_anterior=$table->share_date;
                            ?>
                            <?php echo e($diff->days); ?>

                        </td>
                        <td><?php echo e(number_format($table->capital,2,'.',',')); ?></td>
                        <td><?php echo e(number_format($table->interest,2,'.',',')); ?></td>
                        <td><?php echo e(number_format($table->total,2,'.',',')); ?></td>
                        <td><?php echo e(number_format($table->capital_balance,2,'.',',')); ?></td>
                        <?php
                            $tot_dias=$tot_dias+$diff->days;
                            $tot_capital=$tot_capital+$table->capital;
                            $tot_interes=$tot_interes+$table->interest;
                            $tot_total=$tot_total+$table->total;
                        ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th style="text-align:right">TOTALES</th>
                    <th style="border:1px solid #000"><?php echo e($tot_dias); ?></th>
                    <th style="border:1px solid #000;text-align:right"><?php echo e(number_format($tot_capital,2,'.',',')); ?></th>
                    <th style="border:1px solid #000;text-align:right"><?php echo e(number_format($tot_interes,2,'.',',')); ?></th>
                    <th style="border:1px solid #000;text-align:right"><?php echo e(number_format($tot_total,2,'.',',')); ?></th>
                    <th style="border:0"></th>
                </tr>
            </table>
            <br><br><br><br><br>
            <table style="width:50%">
                <tr>
                    <td style="width:40%;border-bottom:1px solid #000;text-align:left">(f)</td>
                    <td style="width:20%;"></td>
                    <td style="width:40%;border-bottom:1px solid #000;text-align:left">(f)</td>
                </tr>
                <tr>
                    <td style="text-align:center">Por institución</td>
                    <td></td>
                    <td style="text-align:center">Usuario por Aceptación</td>
                </tr>
            </table>
        </center>
    </body>
</html><?php /**PATH C:\xampp\htdocs\blunkredit\resources\views/pdf/regla-general.blade.php ENDPATH**/ ?>