<img src="/build/assets/img/logo.png" style="height:40px" />
<?php /**PATH C:\xampp\htdocs\blunkredit\resources\views/components/application-mark.blade.php ENDPATH**/ ?>