<img src="/build/assets/img/logo.png" style="height:40px" />
<?php /**PATH C:\xampp\htdocs\blunkredit\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>