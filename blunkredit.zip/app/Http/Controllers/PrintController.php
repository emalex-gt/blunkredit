<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Builder;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Models\Credit;
use App\Models\AmortizationSchedule;
use App\Models\User;
use App\Models\Prepayment;

class PrintController extends Controller
{
    //
    public function reglamodificada($id){
        $credit=Credit::find($id);
        return view('pdf.regla-modificada',compact('credit'));
        $pdf = Pdf::loadView('pdf.regla-modificada',compact('credit'));
        return $pdf->download('regla-modificada-'.$id.'.pdf');
    }
    public function reglageneral($id){
        $credit=Credit::find($id);
        return view('pdf.regla-general',compact('credit'));
        $pdf = Pdf::loadView('pdf.regla-general',compact('credit'));
        return $pdf->download('regla-general-'.$id.'.pdf');
    }
    public function reportemorosos(){
        $amortizations = AmortizationSchedule::where('days_delayed','>',0)
                            ->where('total_payment',0)
                            ->orderBy('id','desc')
                            ->get();
        $users=User::where('id',1)->get();
        return view('pdf.reporte-morosos',compact('amortizations','users'));
        $pdf = Pdf::loadView('pdf.reporte-morosos',compact('amortizations','users'));
        return $pdf->download('reporte-morosos-'.$id.'.pdf');
    }
    public function reporteproyeccion($desde,$hasta){
        $amortizations = AmortizationSchedule::where('total_payment',0)
                            ->whereBetween('share_date',[$desde.' 00:00:00',$hasta.' 23:59:59'])
                            ->orderBy('share_date','asc')
                            ->paginate(30);
        return view('pdf.reporte-proyeccion',compact('amortizations','desde','hasta'));
        $pdf = Pdf::loadView('pdf.reporte-proyeccion',compact('amortizations'));
        return $pdf->download('reporte-proyeccion-'.$id.'.pdf');
    }
    public function imprimir_recibo($id){
        $amortization=AmortizationSchedule::find($id);
        return view('pdf.imprimir-recibo',compact('amortization'));
    }
    public function imprimir_adelanto($id){
        $prepayment=Prepayment::find($id);
        return view('pdf.imprimir-adelanto',compact('prepayment'));
    }
}
