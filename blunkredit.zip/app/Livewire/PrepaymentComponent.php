<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\AmortizationSchedule;
use App\Models\Prepayment;
use Auth;

class PrepaymentComponent extends Component
{
    public $open=false;
    public $amortizationschedule;
    public $receipt_number;

    protected $rules = [
        'receipt_number' => 'required'
    ];

    public function mount(AmortizationSchedule $amortizationschedule){
        $this->amortizationschedule=$amortizationschedule;
    }

    public function render()
    {
        return view('livewire.prepayment-component');
    }
    
    public function save(){
        $this->validate();

        $user = Auth::user();
        Prepayment::create([
            'amortization_schedule_id' => $this->amortizationschedule->id,
            'date' => $this->amortizationschedule->share_date,
            'payment_date' => date('Y-m-d H:i:s'),
            'receipt_number' => $this->receipt_number,
            'payment_user' => $user->id,
            'payment_at' => date('Y-m-d H:i:s'),
            'status' => 1
        ]);

        $this->reset('receipt_number','open');
        $this->dispatch('ok');
        $this->dispatch('redirect');

    }
}
