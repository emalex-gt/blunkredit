<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\Credit;
use App\Models\AdministrativeExpense;
use App\Models\Fund;
use Auth;

class CreditExpendComponent extends Component
{

    public $open=false;
    public $credit;
    public $fund_id,$desembolso,$contrato=750,$traspaso=150;

    public function mount(Credit $credit){
        $this->credit=$credit;
        $this->desembolso=number_format(($this->credit->initial_credit_capital * 0.055),2,'.','');
    }

    protected $rules = [
        'desembolso' => 'required',
        'contrato' => 'required',
        'traspaso' => 'required',
        'fund_id' => 'required'
    ];
    
    public function render()
    {
        $funds=Fund::where('status',1)->get();
        return view('livewire.credit-expend-component',compact('funds'));
    }
    public function save()
    {
        $user = Auth::user();
        $this->validate();
        if($this->traspaso >= 150){
            AdministrativeExpense::create([
                'credit_id' => $this->credit->id,
                'type' => 1,
                'description' => '',
                'amount' => $this->desembolso,
                'created_user' => $user->id,
                'created_at' => date('Y-m-d H:i:s')
            ]);
            AdministrativeExpense::create([
                'credit_id' => $this->credit->id,
                'type' => 2,
                'description' => '',
                'amount' => $this->contrato,
                'created_user' => $user->id,
                'created_at' => date('Y-m-d H:i:s')
            ]);
            AdministrativeExpense::create([
                'credit_id' => $this->credit->id,
                'type' => 3,
                'description' => '',
                'amount' => $this->traspaso,
                'created_user' => $user->id,
                'created_at' => date('Y-m-d H:i:s')
            ]);
            $this->credit->status=3;
            $user=Auth::user();
            $this->credit->fund_id=$this->fund_id;
            $this->credit->expended_user=$user->id;
            $this->credit->expended_at=date('Y-m-d H:i:s');
            $this->credit->save();
            $this->dispatch('ok');
            $this->dispatch('redirect');
        } else {
            $this->dispatch('error');
        }
    }
}
