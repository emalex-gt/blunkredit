<?php

namespace App\Livewire;

use Livewire\Component;
use Illuminate\Database\Eloquent\Builder;
use App\Models\AmortizationSchedule;
use DB;

class ReportProyeccionComponent extends Component
{
    public $desde;
    public $hasta;
    
    public function mount(){
        $this->desde=date('Y-m').'-01';
        $this->hasta=date('Y-m-d');
    }

    public function render()
    {
        $amortizations = AmortizationSchedule::where('total_payment',0)
                            ->whereBetween('share_date',[$this->desde.' 00:00:00',$this->hasta.' 23:59:59'])
                            ->orderBy('share_date','asc')
                            ->paginate(30);
        return view('livewire.report-proyeccion-component',compact('amortizations'));
    }
}
