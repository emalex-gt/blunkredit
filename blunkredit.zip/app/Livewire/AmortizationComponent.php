<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\AmortizationSchedule;
use App\Models\Credit;
use Auth;

class AmortizationComponent extends Component
{
    public $open=false;
    public $amortizationschedule;

    protected $rules = [
        'amortizationschedule.receipt_number' => 'required'
    ];

    public function mount(AmortizationSchedule $amortizationschedule){
        $this->amortizationschedule=$amortizationschedule;
    }

    public function render()
    {
        return view('livewire.amortization-component');
    }
    
    public function save(){
        $this->validate();

        $user = Auth::user();
        $credit = Credit::find($this->amortizationschedule->credit_id);
        
        //Save Amortization
        $this->amortizationschedule->payment_date=date('Y-m-d H:i:s');
        $this->amortizationschedule->total_payment=($this->amortizationschedule->capital + $this->amortizationschedule->interest + $this->amortizationschedule->delay);
        $this->amortizationschedule->capital_balance_payment=$credit->amortized_credit_capital + $this->amortizationschedule->capital;
        $this->amortizationschedule->interest_balance_payment=$credit->interest_paid + $this->amortizationschedule->interest;
        $this->amortizationschedule->total_balance_payment=$credit->total_paid + $this->amortizationschedule->total_payment;
        $this->amortizationschedule->payment_user=$user->id;
        $this->amortizationschedule->payment_at=date('Y-m-d H:i:s');
        $this->amortizationschedule->save();

        //Update Credit
        $credit->amortized_credit_capital= $credit->amortized_credit_capital + $this->amortizationschedule->capital;
        $credit->pending_credit_capital= $credit->pending_credit_capital - $this->amortizationschedule->capital;
        $credit->interest_paid= $credit->interest_paid + $this->amortizationschedule->interest;
        $credit->delay_paid= $credit->delay_paid + $this->amortizationschedule->delay;
        $credit->total_paid= $credit->total_paid + $this->amortizationschedule->total_payment;
        $credit->save();

        $this->reset('open');
        $this->dispatch('ok');
        $this->dispatch('redirect');
    }
}
