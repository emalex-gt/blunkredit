<div class="p-6 lg:p-8 bg-white border-b border-gray-200">
    <x-application-logo class="block h-12 w-auto" />

    <h1 class="mt-8 text-2xl font-medium text-gray-900">
        Bievenido a Blunkredit, tu aplicación de Créditos!
    </h1>

    <p class="mt-6 text-gray-500 leading-relaxed">
        Apreciamos habernos elegido para la gestión de sus operaciones. Mientras se usa la aplicación se instalaran actualizaciones, sientase en libertad de comunicarnos cualquier duda, incidencia o solicitud para que sus operaciones sean más eficientes.
    </p>
</div>
