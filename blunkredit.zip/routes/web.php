<?php

use Illuminate\Support\Facades\Route;
use App\Livewire\TecnologyComponent;
use App\Livewire\FundComponent;
use App\Livewire\GuaranteeComponent;
use App\Livewire\CreditLineComponent;
use App\Livewire\TimeLimitComponent;
use App\Livewire\InterestComponent;
use App\Livewire\PolicyComponent;
use App\Livewire\UserComponent;
use App\Livewire\CustomerComponent;
use App\Livewire\CreditsComponent;
use App\Livewire\CreditListComponent;
use App\Livewire\CreditShowComponent;
use App\Http\Controllers\PrintController;
use App\Livewire\ReportRecuperacionComponent;
use App\Livewire\ReportAdelantadosComponent;
use App\Livewire\ReportColocacionComponent;
use App\Livewire\ReportMorososComponent;
use App\Livewire\ReportProyeccionComponent;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {
    Route::get('/', function () {
        return view('dashboard');
    })->name('dashboard');

    Route::get('/tecnologias', TecnologyComponent::class)->name('tecnologias');
    Route::get('/fondos', FundComponent::class)->name('fondos');
    Route::get('/garantias', GuaranteeComponent::class)->name('garantias');
    Route::get('/lineas-de-credito', CreditLineComponent::class)->name('lineas-de-credito');
    Route::get('/plazos', TimeLimitComponent::class)->name('plazos');
    Route::get('/intereses', InterestComponent::class)->name('intereses');
    Route::get('/politicas', PolicyComponent::class)->name('politicas');
    Route::get('/usuarios', UserComponent::class)->name('usuarios');    

    Route::get('/clientes', CustomerComponent::class)->name('clientes');
    Route::get('/creditos', CreditsComponent::class)->name('creditos');
    Route::get('/creditos/lista', CreditListComponent::class)->name('creditos-lista');
    Route::get('/credito/{id}', CreditShowComponent::class)->name('credito');
    Route::get('/reporte/recuperacion', ReportRecuperacionComponent::class)->name('reporte-recuperacion');
    Route::get('/reporte/adelantados', ReportAdelantadosComponent::class)->name('reporte-adelantados');
    Route::get('/reporte/colocacion', ReportColocacionComponent::class)->name('reporte-colocacion');
    Route::get('/reporte/morosos', ReportMorososComponent::class)->name('reporte-morosos');
    Route::get('/reporte/proyeccion', ReportProyeccionComponent::class)->name('reporte-proyeccion');

    Route::get('/regla-modificada/{id}', [PrintController::class,'reglamodificada'])->name('regla-modificada');
    Route::get('/regla-general/{id}', [PrintController::class,'reglageneral'])->name('regla-general');
    Route::get('/print/reporte/morosos', [PrintController::class,'reportemorosos'])->name('print-reporte-morosos');
    Route::get('/print/reporte/proyeccion/{desde}/{hasta}', [PrintController::class,'reporteproyeccion'])->name('print-reporte-proyeccion');
    Route::get('/print/recibo/{id}', [PrintController::class,'imprimir_recibo'])->name('print-recibo');
    Route::get('/print/adelanto/{id}', [PrintController::class,'imprimir_adelanto'])->name('print-adelanto');
});
